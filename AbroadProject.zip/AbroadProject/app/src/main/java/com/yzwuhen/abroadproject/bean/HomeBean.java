package com.yzwuhen.abroadproject.bean;

import com.yzwuhen.abroadproject.ui.data.BannerData;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;
import com.yzwuhen.abroadproject.ui.data.NewArrivalsData;
import com.yzwuhen.abroadproject.ui.data.RecommendData;

import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class HomeBean extends NetBean {

    /**
     * data : {"banner":[{"promote_id":1,"title":"百度友情链接","img_path":"","url":"/common/promote/v0/1"}],"new_arrivals":[],"recommend":[],"goods_list":false}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * banner : [{"promote_id":1,"title":"百度友情链接","img_path":"","url":"/common/promote/v0/1"}]
         * new_arrivals : []
         * recommend : []
         * goods_list : []
         */


        private List<BannerData> banner;
        private List<NewArrivalsData> new_arrivals;
        private List<RecommendData> recommend;
        private List<GoodsListData> goods_list;

        public List<GoodsListData> getGoods_list() {
            return goods_list;
        }

        public void setGoods_list(List<GoodsListData> goods_list) {
            this.goods_list = goods_list;
        }

        public List<BannerData> getBanner() {
            return banner;
        }

        public void setBanner(List<BannerData> banner) {
            this.banner = banner;
        }

        public List<NewArrivalsData> getNew_arrivals() {
            return new_arrivals;
        }

        public void setNew_arrivals(List<NewArrivalsData> new_arrivals) {
            this.new_arrivals = new_arrivals;
        }

        public List<RecommendData> getRecommend() {
            return recommend;
        }

        public void setRecommend(List<RecommendData> recommend) {
            this.recommend = recommend;
        }
    }
}
