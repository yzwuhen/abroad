package com.yzwuhen.abroadproject.allinterface;

import android.view.View;

/**
 * Created by yz_wuhen on 2017/9/28.
 */

public interface VhOnItemClickListener {
    void onItemOnclick(View v, int position);
}
