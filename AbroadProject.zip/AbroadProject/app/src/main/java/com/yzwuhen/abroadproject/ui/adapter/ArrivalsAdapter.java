package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.NewArrivalsData;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;
import com.yzwuhen.abroadproject.utils.SignUtils;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class ArrivalsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private List<NewArrivalsData> mList;
    private VhOnItemClickListener mItemClickListener;

    public ArrivalsAdapter(Context context, List<NewArrivalsData> list, VhOnItemClickListener vhOnItemClickListener) {

        this.mContext = context;
        this.mList = list;
        this.mItemClickListener = vhOnItemClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
          View view = View.inflate(parent.getContext(), R.layout.item_goods_v, null);
        //   View view = LayoutInflater.from(mContext).inflate(R.layout.item_goods_v,parent, false);
        return new ArrivalsHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ArrivalsHolder arrivalsHolder = (ArrivalsHolder) holder;
        String ss ="$"+mList.get(position).getPrice();
        arrivalsHolder.mTvPrice.setText(SignUtils.bigText("$0.00"));
        arrivalsHolder.mTvCostPrice.setText(SignUtils.bigText(ss));
        arrivalsHolder.mTvCostPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG );
        arrivalsHolder.mTvGoodsName.setText(mList.get(position).getTitle());
        ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),arrivalsHolder.mIvPic,mList.get(position).getPreview(),R.mipmap.goods_defult);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class ArrivalsHolder extends RecyclerView.ViewHolder {

        @Bind(R.id.iv_pic)
        CusImageView mIvPic;
        @Bind(R.id.tv_goods_name)
        TextView mTvGoodsName;
        @Bind(R.id.tv_price)
        TextView mTvPrice;
        @Bind(R.id.tv_cost_price)
        TextView mTvCostPrice;
        public ArrivalsHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(v, getAdapterPosition());

                }
            });
        }
    }

}
