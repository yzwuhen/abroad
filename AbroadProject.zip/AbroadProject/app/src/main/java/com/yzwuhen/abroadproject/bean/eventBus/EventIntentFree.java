package com.yzwuhen.abroadproject.bean.eventBus;

public class EventIntentFree {

    private int type;
    public EventIntentFree(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
