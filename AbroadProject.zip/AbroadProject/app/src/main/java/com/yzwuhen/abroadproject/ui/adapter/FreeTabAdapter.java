package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.FreeTabData;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class FreeTabAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private List<FreeTabData> mList;
    private VhOnItemClickListener mItemClickListener;

    public FreeTabAdapter(Context context, List<FreeTabData> list, VhOnItemClickListener vhOnItemClickListener) {

        this.mContext = context;
        this.mList = list;
        this.mItemClickListener = vhOnItemClickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.item_free_tab, null);
        return new FreeTbaVh(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        FreeTbaVh freeTbaVh = (FreeTbaVh) holder;
        if (mList.get(position).isSelect()){
           freeTbaVh.mIvLine.setVisibility(View.VISIBLE);
        }else {
            freeTbaVh.mIvLine.setVisibility(View.GONE);
        }
        freeTbaVh.mTvTab.setText(mList.get(position).getTitle());

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class FreeTbaVh extends RecyclerView.ViewHolder {
        @Bind(R.id.tv_tabs)
        TextView mTvTab;
        @Bind(R.id.iv_line)
        ImageView mIvLine;
        public FreeTbaVh(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(mTvTab,getAdapterPosition());
                }
            });

        }
    }


}
