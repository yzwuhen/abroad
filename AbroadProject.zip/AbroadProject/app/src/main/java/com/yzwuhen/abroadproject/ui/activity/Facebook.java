package com.yzwuhen.abroadproject.ui.activity;

import android.app.Activity;

public class Facebook extends Activity {

}
