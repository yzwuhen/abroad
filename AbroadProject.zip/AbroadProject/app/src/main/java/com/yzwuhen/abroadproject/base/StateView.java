package com.yzwuhen.abroadproject.base;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;


/**
 * Created by yz_wuhen on 2017/8/25.
 */

public class StateView extends LinearLayout {


    ProgressBar mPbState;
    TextView mTvState;
    LinearLayout mLyLoad;
    private View mView;
    public StateView(Context context) {
        super(context);
        initView();
    }


    public StateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public StateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }


    private void initView() {
        mView = View.inflate(getContext(), R.layout.base_view_layout, this);
//        mPbState = (ProgressBar) mView.findViewById(R.id.pb_state);
//        mLyLoad =findViewById(R.id.ly_load);

    }

    public void setLoading() {
//        mLyLoad.setVisibility(VISIBLE);
//        mTvState.setVisibility(GONE);
    }

    public void hidView() {
//        mLyLoad.setVisibility(GONE);
//        mTvState.setVisibility(GONE);

    }


}
