package com.yzwuhen.abroadproject.ui.data;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class FreeTabData {

    /**
     * type_id : 2
     * title : 测试分类7
     */

    private int type_id;
    private String title;
    private boolean isSelect;//是否选中

    public int getType_id() {
        return type_id;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
