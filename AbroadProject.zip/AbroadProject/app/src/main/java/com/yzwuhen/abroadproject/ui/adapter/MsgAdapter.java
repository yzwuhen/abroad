package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.MsgData;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class MsgAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private VhOnItemClickListener mItemClickListener;
    private List<MsgData> mList;


    public MsgAdapter(Context context, List<MsgData> list, VhOnItemClickListener vhOnItemClickListener) {

        this.mContext = context;
        this.mItemClickListener = vhOnItemClickListener;
        this.mList =list;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.item_msg, null);
        return new MsgVh(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MsgVh msgVh = (MsgVh) holder;
        if (position==0){
            msgVh.mIvIcon.setImageResource(R.mipmap.push_img);
            msgVh.mTvMsgTitle.setText("Featured Push");
        }
        else if (position==1){
            msgVh.mIvIcon.setImageResource(R.mipmap.sys_img);
            msgVh.mTvMsgTitle.setText("System notification");
        }
        else {
            msgVh.mIvIcon.setImageResource(R.mipmap.feedback_img);
            msgVh.mTvMsgTitle.setText("Account notification");
        }
        if (mList.size()>position){
            msgVh.mTvContent.setText(mList.get(position).getMsg());
            if (mList.get(position).getStatus()==0){
                msgVh.mTvTip.setVisibility(View.GONE);
            }else {
                msgVh.mTvTip.setVisibility(View.VISIBLE);
            }
        }

    }

    @Override
    public int getItemCount() {
        return 3;
    }

    public class MsgVh extends RecyclerView.ViewHolder {
        @Bind(R.id.iv_icon)
        ImageView mIvIcon;
        @Bind(R.id.tv_msg_title)
        TextView mTvMsgTitle;
        @Bind(R.id.tv_content)
        TextView mTvContent;
        @Bind(R.id.tv_time)
        TextView mTvTime;
        @Bind(R.id.tv_tip)
        TextView mTvTip;
        public MsgVh(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(v,getAdapterPosition());
                }
            });
        }
    }


}
