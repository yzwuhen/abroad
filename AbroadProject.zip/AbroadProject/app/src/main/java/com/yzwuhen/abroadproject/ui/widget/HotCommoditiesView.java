package com.yzwuhen.abroadproject.ui.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.adapter.CommodityAdapter;
import com.yzwuhen.abroadproject.ui.adapter.HotCommodityAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class HotCommoditiesView extends LinearLayout implements VhOnItemClickListener {

    private Context mContext;


    private List<String> mList;
    private RecyclerView mRecyclerView;
    private HotCommodityAdapter mAdapter;

    public HotCommoditiesView(Context context) {
        super(context);
        initView(context);
    }

    public HotCommoditiesView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public HotCommoditiesView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }


    private void initView(Context context) {
        mContext = context;
        View.inflate(mContext, R.layout.item_hot_commodity, this);


        mRecyclerView = findViewById(R.id.rv_list);

        mRecyclerView.setLayoutManager(new GridLayoutManager(mContext, 2));


        mList =new ArrayList<>();

        mAdapter = new HotCommodityAdapter(mContext,mList,this);
        mRecyclerView.setAdapter(mAdapter);

    }



    @Override
    public void onItemOnclick(View v, int position) {

    }
}