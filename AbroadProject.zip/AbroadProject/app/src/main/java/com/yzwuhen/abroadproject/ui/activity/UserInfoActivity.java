package com.yzwuhen.abroadproject.ui.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnOptionsSelectListener;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.bigkoo.pickerview.view.TimePickerView;
import com.jph.takephoto.app.TakePhoto;
import com.jph.takephoto.app.TakePhotoImpl;
import com.jph.takephoto.model.CropOptions;
import com.jph.takephoto.model.InvokeParam;
import com.jph.takephoto.model.TContextWrap;
import com.jph.takephoto.model.TResult;
import com.jph.takephoto.permission.InvokeListener;
import com.jph.takephoto.permission.PermissionManager;
import com.jph.takephoto.permission.TakePhotoInvocationHandler;
import com.orhanobut.hawk.Hawk;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.ui.data.UserData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.UserInfoPresenter;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;
import com.yzwuhen.abroadproject.utils.PopWindowUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class UserInfoActivity extends BaseActivity<NetBean> implements TakePhoto.TakeResultListener,InvokeListener {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.iv_user_pic)
    CusImageView mIvUserPic;
    @Bind(R.id.rl_account)
    RelativeLayout mRlAccount;
    @Bind(R.id.rl_nick)
    RelativeLayout mRlNick;
    @Bind(R.id.rl_sex)
    RelativeLayout mRlSex;
    @Bind(R.id.rl_birth)
    RelativeLayout mRlBirth;
    @Bind(R.id.rl_address)
    RelativeLayout mRlAddress;
    @Bind(R.id.tv_account)
    TextView mTvAccount;
    @Bind(R.id.tv_nick)
    TextView mTvNick;
    @Bind(R.id.tv_sex)
    TextView mTvSex;
    @Bind(R.id.tv_birth)
    TextView mTvBirth;
    @Bind(R.id.iv_logo)
    ImageView mImageView;

    private UserData mUserData;
    //图片堆
    private String pics;

    private TakePhoto takePhoto;
    private InvokeParam invokeParam;

    private UserInfoPresenter mPresenter;

    private String mUrl;
    private List<String> mSexList;
    private OptionsPickerView pvOptions;
    private  TimePickerView pvTime;
    private PopWindowUtils mPopWindowUtils;
    private EditText mEtNick;

    @Override
    protected void initView() {
        super.initView();

        mTvTitle.setText(getResources().getString(R.string.Personal_information));
        mLyRight.setVisibility(View.INVISIBLE);
        mIvLeft.setImageResource(R.mipmap.sys_back);
        mUserData = App.getInstance().getUserDate();

        mTvAccount.setText(mUserData.getUsername());
        mTvNick.setText(mUserData.getNickname());
        mTvSex.setText(mUserData.getSex());
        mTvBirth.setText(mUserData.getBirthday());
        ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),mIvUserPic,mUserData.getHead_img(),R.mipmap.user_defult_pic);

        mSexList = new ArrayList<>();
        mSexList.add("Secrecy");
        mSexList.add("Male");
        mSexList.add("Female");


    }

    @Override
    public void bindDataToView(NetBean netBean) {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_user_info;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new UserInfoPresenter(this);
    }


    @OnClick({R.id.ly_left, R.id.iv_user_pic, R.id.rl_account, R.id.rl_nick, R.id.rl_sex, R.id.rl_birth, R.id.rl_address,R.id.rl_amazon})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
                finish();
                break;
            case R.id.iv_user_pic:
                openAlbum();
                break;
            case R.id.rl_account:
                break;
            case R.id.rl_nick:
                showNick();
                //  jumpActivity(null,ModifyNickActivity.class);
                break;
            case R.id.rl_sex:
                showSex();
                break;
            case R.id.rl_birth:
                showTimePicker();
                break;
            case R.id.rl_address:
                mUrl = AppNetConfig.WEB_URL +"addresslist?";
                Bundle bundle =new Bundle();
                bundle.putString(AppConfig.WEB_LOAD_URL,mUrl);
                bundle.putString(AppConfig.WEB_TITLE,"Shipping address");
                jumpActivity(bundle, WebActivity.class);
                break;
            case R.id.rl_amazon:
                mUrl = AppNetConfig.WEB_URL +"amazon-profile?";
                Bundle bundle1 =new Bundle();
                bundle1.putString(AppConfig.WEB_LOAD_URL,mUrl);
                bundle1.putString(AppConfig.WEB_TITLE,"Amazon");
                jumpActivity(bundle1, WebActivity.class);
                break;
        }
    }

    private void showTimePicker() {
        //时间选择器
        if (pvTime == null){
            pvTime= new TimePickerBuilder(this, new OnTimeSelectListener() {
                @Override
                public void onTimeSelect(Date date, View v) {
                    mTvBirth.setText(getTime(date));
                    String [] births =getTime(date).split("-");
                    mPresenter.upDateBirth(births[0],births[1],births[2]);
                }

            })
                    .setCancelText("Cancel")//取消按钮文字
                    .setSubmitText("Sure")//确认按钮文字
                    .isCenterLabel(true)
                    .setLabel("","","","","","").build();
        }

        pvTime.show();
    }
    private String getTime(Date date) {//可根据需要自行截取数据显示
        Log.d("getTime()", "choice date millis: " + date.getTime());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }
    private void showSex(){
//条件选择器

        if (pvOptions==null){
            pvOptions = new OptionsPickerBuilder(this, new OnOptionsSelectListener() {
                @Override
                public void onOptionsSelect(int options1, int option2, int options3 ,View v) {
                    //返回的分别是三个级别的选中位置
                    String tx = mSexList.get(options1);
                    mPresenter.upDateSex(options1);
                    mTvSex.setText(tx);
                }
            }).setCancelText("Cancel")//取消按钮文字
              .setSubmitText("Sure")//确认按钮文字
              .build();
            pvOptions.setPicker(mSexList);
        }

        pvOptions.show();
    }
    private void showNick(){
        if (mPopWindowUtils ==null){

            mPopWindowUtils =PopWindowUtils.getInstance();
            mPopWindowUtils.general(this, new PopWindowUtils.onViewListener() {
                @Override
                public void getView(PopupWindow pop, View view, View parent) {
                    mEtNick = view.findViewById(R.id.et_nick);
                    TextView mTvCancle = view.findViewById(R.id.tv_cancel);
                    TextView mTvSure = view.findViewById(R.id.tv_sure);

                    mTvCancle.setOnClickListener(mOnClickListener);
                    mTvSure.setOnClickListener(mOnClickListener);

                    mEtNick.setText(App.getInstance().getUserDate().getNickname());


                }
            },mTvNick,R.layout.pop_modify_nick,true);
        }
        mPopWindowUtils.showPop(mTvNick);


    }
    View.OnClickListener mOnClickListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mPopWindowUtils.hidePop();
            if (v.getId()==R.id.tv_sure){
                mTvNick.setText(mEtNick.getText().toString().trim());
                mPresenter.upDateNick(mEtNick.getText().toString().trim());
            }

        }
    };

    public void openAlbum(){
        File file = new File(Environment.getExternalStorageDirectory(), "/temp/" + System.currentTimeMillis() + ".jpg");
        if (!file.getParentFile().exists()) file.getParentFile().mkdirs();
        Uri imageUri = Uri.fromFile(file);
        getTakePhoto().onPickFromGalleryWithCrop(imageUri, getCropOptions());
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        getTakePhoto().onCreate(savedInstanceState);

        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        getTakePhoto().onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        getTakePhoto().onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //以下代码为处理Android6.0、7.0动态权限所需
        PermissionManager.TPermissionType type=PermissionManager.onRequestPermissionsResult(requestCode,permissions,grantResults);
        PermissionManager.handlePermissionsResult(this,type,invokeParam,this);
    }
    /**
     *  获取TakePhoto实例
     * @return
     */
    public TakePhoto getTakePhoto(){
        if (takePhoto==null){
            takePhoto= (TakePhoto) TakePhotoInvocationHandler.of(this).bind(new TakePhotoImpl(this,this));
        }
        return takePhoto;
    }
    private CropOptions getCropOptions() {

        CropOptions.Builder builder = new CropOptions.Builder();
        builder.setOutputX(400).setOutputY(400);
        builder.setWithOwnCrop(false);
        return builder.create();
    }
    @Override
    public void takeSuccess(TResult result) {
       mPresenter.upLoadFile(result.getImage().getOriginalPath());
    }

    @Override
    public void takeFail(TResult result, String msg) {

    }

    @Override
    public void takeCancel() {

    }

    @Override
    public PermissionManager.TPermissionType invoke(InvokeParam invokeParam) {
        PermissionManager.TPermissionType type=PermissionManager.checkPermission(TContextWrap.of(this),invokeParam.getMethod());
        if(PermissionManager.TPermissionType.WAIT.equals(type)){
            this.invokeParam=invokeParam;
        }
        return type;
    }

    public void successed(String file_path) {

        mUserData.setHead_img(file_path);
        ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),mIvUserPic,mUserData.getHead_img(),R.mipmap.user_defult_pic);
        Hawk.put(AppConfig.USER_INFO,mUserData);
        App.getInstance().setUserData(mUserData);

    }
    public void successedBirth(String date) {

        mUserData.setBirthday(mTvBirth.getText().toString().trim());
        Hawk.put(AppConfig.USER_INFO,mUserData);
        App.getInstance().setUserData(mUserData);

    }
    public void successedSex(int sex) {

        mUserData.setSex(sex);
        Hawk.put(AppConfig.USER_INFO,mUserData);
        App.getInstance().setUserData(mUserData);

    }
    public void successedNick() {
        mUserData.setNickname(mTvNick.getText().toString());
        Hawk.put(AppConfig.USER_INFO,mUserData);
        App.getInstance().setUserData(mUserData);

    }
}
