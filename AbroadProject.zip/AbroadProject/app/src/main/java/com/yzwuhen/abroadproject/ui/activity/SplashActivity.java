package com.yzwuhen.abroadproject.ui.activity;

import android.os.Handler;
import android.os.Message;
import com.yzwuhen.abroadproject.MainActivity;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;

public class SplashActivity extends BaseActivity<NetBean> {


    Handler mHandler =new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            jumpActivity(null, MainActivity.class);
            finish();
            mHandler.removeCallbacksAndMessages(null);
        }
    };
    @Override
    protected void initView() {
        super.initView();

        mHandler.sendEmptyMessageDelayed(1,1500);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_splash;
    }

    @Override
    public BasePresenter getPresenter() {
        return null;
    }

    @Override
    public void bindDataToView(NetBean netBean) {

    }
}
