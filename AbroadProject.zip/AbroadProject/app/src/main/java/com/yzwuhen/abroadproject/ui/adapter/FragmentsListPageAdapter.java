package com.yzwuhen.abroadproject.ui.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/22/022.
 */

public class FragmentsListPageAdapter extends FragmentPagerAdapter {
    private List<String> mTitleList;
    private List<Fragment> mFragmentList;
    public FragmentsListPageAdapter(FragmentManager fm, List<String> list, List<Fragment> fragmentList) {
        super(fm);
        this.mTitleList = list;
        this.mFragmentList =fragmentList;
    }

    @Override
    public Fragment getItem(int position) {

        return mFragmentList.get(position);
    }

    @Override
    public int getCount() {
        return mFragmentList == null ? 0 : mFragmentList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        if (mTitleList!=null&&mTitleList.size()>0){
            return mTitleList.get(position % mTitleList.size());
        }
        return super.getPageTitle(position);
    }
}

