package com.yzwuhen.abroadproject.ui.activity;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventPage;
import com.yzwuhen.abroadproject.ui.adapter.FragmentsListPageAdapter;
import com.yzwuhen.abroadproject.ui.fragment.LoginFragment;
import com.yzwuhen.abroadproject.ui.fragment.RegisterFragment;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import fr.castorflex.android.verticalviewpager.VerticalViewPager;

public class LoginAndReister extends BaseActivity<NetBean> {
    @Bind(R.id.vp_content)
    VerticalViewPager vpContent;


    private List<Fragment> mFragmentList;
   private FragmentsListPageAdapter mPageAdapter;
    private static final float MIN_SCALE = 0.75f;
    private static final float MIN_ALPHA = 0.75f;

    private int mPageIndex;
    @Override
    protected void initView() {
        super.initView();

        EventBus.getDefault().register(this);
        mFragmentList = new ArrayList<>();
        for (int i=0;i<99;i++){
            mFragmentList.add(new LoginFragment());
            mFragmentList.add(new RegisterFragment());

        }
        mPageAdapter = new FragmentsListPageAdapter(getSupportFragmentManager(), null, mFragmentList);
        vpContent.setAdapter(mPageAdapter);

        mPageIndex = getIntent().getIntExtra(AppConfig.LOGIN_PAGE_TYPE,0);
        vpContent.setCurrentItem(mPageIndex,true);

    }
    @Subscribe
    public void setPage(EventPage eventPage){
        if (eventPage.getType()==1){
            vpContent.setCurrentItem(1,true);
        }else {
            vpContent.setCurrentItem(0,true);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_login_regist;
    }

    @Override
    public BasePresenter getPresenter() {
        return null;
    }

    @Override
    public void bindDataToView(NetBean netBean) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
