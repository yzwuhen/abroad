package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class ShareSpeedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private int totals;

    public ShareSpeedAdapter(Context context) {

        this.mContext = context;
    }



    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View view = View.inflate(mContext, R.layout.item_share_speed, null);
            return new ShareSpeedVh(view);

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            ShareSpeedVh shareSpeedVh = (ShareSpeedVh) holder;
            if (totals>0){
                if (position==0){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }

            if (totals>2000){
                if (position==1){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }

            if (totals>4000){
                if (position==2){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }

            if (totals>6000){
                if (position==3){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }
            if (totals>8000){
                if (position==4){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }
            if (totals>10000){
                if (position==5){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }
            if (totals>12000){
                if (position==6){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }
            if (totals>14000){
                if (position==7){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }

            if (totals>16000){
                if (position==8){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }

            if (totals>18000){
                if (position==9){
                    shareSpeedVh.mIvCircle.setImageResource(R.drawable.circle_blue);
                    shareSpeedVh.mVLine.setBackgroundColor(mContext.getResources().getColor(R.color.blue_drawer));
                }
            }


    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public void setData(int total) {

            this.totals =total;

    }

    public class ShareSpeedVh extends RecyclerView.ViewHolder {
        @Bind(R.id.iv_circle)
        ImageView mIvCircle;
        @Bind(R.id.v_line)
        View mVLine;
        public ShareSpeedVh(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }


}
