package com.yzwuhen.abroadproject.ui.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.liaoinstan.springview.widget.SpringView;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.bean.FreeTabBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventFree;
import com.yzwuhen.abroadproject.bean.eventBus.EventIntentFree;
import com.yzwuhen.abroadproject.ui.activity.SearchActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.adapter.FreeGoodsAdapter;
import com.yzwuhen.abroadproject.ui.adapter.FreeTabAdapter;
import com.yzwuhen.abroadproject.ui.data.FreeTabData;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.FreePresenter;
import com.yzwuhen.abroadproject.ui.widget.GridItemDecoration;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */

public class FreeFragment extends BaseFragment<NetBean> implements VhOnItemClickListener{
    @Bind(R.id.ly_search)
    LinearLayout mLySearch;
    @Bind(R.id.rv_title)
    RecyclerView mRvTitle;
    @Bind(R.id.tv_newest)
    TextView mTvNewest;
    @Bind(R.id.ly_newest)
    LinearLayout mLyNewest;
    @Bind(R.id.tv_hottest)
    TextView mTvHottest;
    @Bind(R.id.ly_hottest)
    LinearLayout mLyHottest;
    @Bind(R.id.tv_value)
    TextView mTvValue;
    @Bind(R.id.ly_value)
    LinearLayout mLyValue;
    @Bind(R.id.recycle_list)
    RecyclerView mRecycleList;
    @Bind(R.id.spring_list)
    SpringView mSpringList;
    @Bind(R.id.ly_no_data)
    LinearLayout mLayout;

    private FreeTabAdapter mFreeTabAdapter;
    private List<FreeTabData> mTabList;

    private List<GoodsListData> mDataList;
    private FreeGoodsAdapter mGoodsAdapter;

    private List<TextView> mTextViews;

    private FreePresenter mPresenter;

    private int tabIndex;

    private String orderBy="newest";//排序  newest： 最新商品  price： 价格排序 hottest： 最热商品
    private int page=1;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        EventBus.getDefault().register(this);
    }

    @Subscribe
    public void clickFree(EventFree eventFree){
        try {
            if (eventFree.getType()==1){
                showCondition(0);
                orderBy ="newest";
                updateOrder(orderBy);
            }else {
                showCondition(1);
                orderBy ="price";
                updateOrder(orderBy);
            }

        }catch (Exception e){

        }
    }



    @Override
    protected void initView() {
        super.initView();

        mTabList = new ArrayList<>();
        mRvTitle.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false));
        mFreeTabAdapter =new FreeTabAdapter(getActivity(),mTabList,this);

        mRvTitle.setAdapter(mFreeTabAdapter);



        mDataList=  new ArrayList<>();
        mGoodsAdapter = new FreeGoodsAdapter(getActivity(),mDataList,this);
        setSpringStyle();


                GridItemDecoration divider = new GridItemDecoration.Builder(mContext)
                .setHorizontalSpan(R.dimen.dp_10)
                .setVerticalSpan(R.dimen.dp_10)
                .setColorResource(R.color.carview_color)
                .setShowLastLine(true)
                .build();
        mRecycleList.addItemDecoration(divider);

        mRecycleList.setLayoutManager(new GridLayoutManager(getActivity(),2));

        mRecycleList.setAdapter(mGoodsAdapter);

        mTextViews=  new ArrayList<>();

        mTextViews.add(mTvNewest);
        mTextViews.add(mTvHottest);
        mTextViews.add(mTvValue);

        mTextViews.get(0).setSelected(true);

        initListener();
    }

    @Override
    protected void initListener() {
        super.initListener();
        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                closeProgressView();
                initData();
            }

            @Override
            public void onLoadmore() {
                mSpringList.setEnable(false);
                closeProgressView();
                if(presenter==null){
                    showSuccessView();
                }else{
                    presenter.loadMoreNetData();
                }
            }
        });
    }
    protected void setSpringStyle(){
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(getContext()));
        mSpringList.setFooter(RefreshHeaderUtils.getFooterView(getContext()));
    }
    @Override
    public void bindDataToView(NetBean netBean) {
        closeRefreshView();
            if (netBean instanceof FreeTabBean){
                mTabList.addAll(((FreeTabBean) netBean).getData().getList());
                mTabList.get(0).setSelect(true);
                mFreeTabAdapter.notifyDataSetChanged();
            }
    }
    public void closeRefreshView() {
        mSpringList.setEnable(true);
        mSpringList.onFinishFreshAndLoad();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_free;
    }

    @Override
    public BasePresenter getPresenter() {

        return mPresenter = new FreePresenter(this,page,orderBy);
    }


    public void  showCondition(int index){

        for (int i=0;i<mTextViews.size();i++){
            if (i==index){
                mTextViews.get(i).setSelected(true);
            }else {
                mTextViews.get(i).setSelected(false);
            }
        }
    }

    @OnClick({R.id.ly_search, R.id.ly_newest, R.id.ly_hottest, R.id.ly_value})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_search:
                jumpActivity(null, SearchActivity.class);
                break;
            case R.id.ly_newest:
                showCondition(0);
                orderBy ="newest";
                updateOrder(orderBy);
                break;
            case R.id.ly_hottest:
                showCondition(1);
                orderBy ="price";
                updateOrder(orderBy);
                break;
            case R.id.ly_value:
                showCondition(2);
                orderBy ="hottest";
                updateOrder(orderBy);
                break;
        }
    }
    public void updateOrder(String orderBys){
        page =1;
        mPresenter.getUpdateCondition(orderBys);
    }

    @Override
    public void onItemOnclick(View v, int position) {
        if (v.getId()==R.id.tv_tabs){
            mTabList.get(tabIndex).setSelect(false);
            mTabList.get(position).setSelect(true);
            mFreeTabAdapter.notifyDataSetChanged();
            tabIndex =position;
            mPresenter.getFreeGoods(mTabList.get(position).getType_id(),page,orderBy);
        }else {

          String mUrl = AppNetConfig.WEB_URL+"goodsdetail?goods_id="+mDataList.get(position).getGoods_id()+"&";
            Bundle bundle =new Bundle();
            bundle.putString(AppConfig.WEB_LOAD_URL,mUrl);
            bundle.putString(AppConfig.WEB_TITLE,"Commodity details");
            jumpActivity(bundle, WebActivity.class);
        }
    }

    //更新数据
    public void upData(FreeGoodsBean netBean, int pages) {
        closeRefreshView();
        if (netBean.getError_code()==0){
            //说明是刷新数据
            if (pages<=1){
                mDataList.clear();
                mDataList.addAll(netBean.getData().getList());
               mGoodsAdapter.notifyDataSetChanged();
            }else {
                mDataList.addAll(netBean.getData().getList());
                mGoodsAdapter.notifyItemChanged(mDataList.size());
            }
        }

        if (mDataList.size()==0){
            mLayout.setVisibility(View.VISIBLE);
        }else {
            mLayout.setVisibility(View.GONE);
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EventBus.getDefault().unregister(this);
    }
}
