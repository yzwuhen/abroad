package com.yzwuhen.abroadproject.ui.widget;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.adapter.ArrivalsAdapter;
import com.yzwuhen.abroadproject.ui.adapter.CommodityAdapter;
import com.yzwuhen.abroadproject.ui.data.RecommendData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class CommoditiesView extends LinearLayout implements VhOnItemClickListener{

    private Context mContext;


    private List<RecommendData> mList;
    private LinearLayout mLyMore;
    private RecyclerView mRecyclerView;
    private CommodityAdapter mAdapter;
    private OnClickListener mOnClickListener;

    public CommoditiesView(Context context, OnClickListener clickListener) {
        super(context);
        this.mOnClickListener =clickListener;
        initView(context);

    }

    public CommoditiesView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public CommoditiesView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }


    private void initView(Context context) {
        mContext = context;
        View.inflate(mContext, R.layout.item_commodities, this);

        mLyMore = findViewById(R.id.ly_commodities_more);

        mRecyclerView = findViewById(R.id.rv_list);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));

        mLyMore.setOnClickListener(mOnClickListener);
        mList =new ArrayList<>();

        mAdapter = new CommodityAdapter(mContext,mList,this);
        mRecyclerView.setAdapter(mAdapter);


    }
    public void setData(List<RecommendData> recommend) {

        mList.clear();
        mList.addAll(recommend);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemOnclick(View v, int position) {
        String mUrl = AppNetConfig.WEB_URL+"goodsdetail?goods_id="+mList.get(position).getGoods_id()+"&";
        Bundle bundle =new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL,mUrl);
        bundle.putString(AppConfig.WEB_TITLE,"Commodity details");

        Intent intent = new Intent();
        intent.setClass(mContext, WebActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        mContext.startActivity(intent);
    }


}