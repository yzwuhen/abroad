package com.yzwuhen.abroadproject.ui.fragment;

import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.liaoinstan.springview.widget.SpringView;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.HomeBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventIntentFree;
import com.yzwuhen.abroadproject.ui.activity.SearchActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.adapter.HomeAdapter;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.HomePresenter;
import com.yzwuhen.abroadproject.ui.widget.ArrivalsView;
import com.yzwuhen.abroadproject.ui.widget.BannerView;
import com.yzwuhen.abroadproject.ui.widget.CommoditiesView;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */

public class HomeFragment extends BaseFragment<HomeBean> implements VhOnItemClickListener {


    @Bind(R.id.recycle_list)
    RecyclerView mRecycleList;
    @Bind(R.id.spring_list)
    SpringView mSpringList;
    @Bind(R.id.ly_home)
    LinearLayout mLayout;

    private HomeAdapter mHomeAdapter;
    private List<View> mViews;

    private BannerView mBannerView;
    private ArrivalsView mArrivalsView;
    private CommoditiesView mCommoditiesView;
    private List<GoodsListData> mList;
    private HomePresenter mPresenter;

    /*
     * 默认是列表 可复写修改
     * */
    protected void recysetLayoutManager() {
        mRecycleList.setLayoutManager(new GridLayoutManager(getActivity(), 2));
    }

    @Override
    protected void initView() {

        mViews = new ArrayList<>();
        mBannerView = new BannerView(getContext());
        mArrivalsView = new ArrivalsView(getContext(), mClickListener);
        mCommoditiesView = new CommoditiesView(getContext(), mClickListener);


        mList = new ArrayList<>();

        setSpringStyle();
        recysetLayoutManager();
        mHomeAdapter = new HomeAdapter(getContext(), mList, mBannerView, mArrivalsView, mCommoditiesView, this);
        mRecycleList.setAdapter(mHomeAdapter);

        mRecycleList.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                int childAdapterPosition = parent.getChildAdapterPosition(view);
                if (childAdapterPosition > 2) {
                    if (childAdapterPosition % 2 == 0) {
                        outRect.set(0, 0, 24, 0);
                    } else {
                        outRect.set(24, 0, 0, 0);
                    }

                }
            }
        });

    }

    protected void setSpringStyle() {
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(getContext()));
        //  mSpringList.setFooter(RefreshHeaderUtils.getFooterView(getContext()));
    }

    @Override
    protected void initListener() {
        super.initListener();
        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                initData();
            }

            @Override
            public void onLoadmore() {

            }
        });
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new HomePresenter(this);
    }

    @Override
    public void bindDataToView(HomeBean homeBean) {

        closeRefreshView();
        if (homeBean.getError_code() == 0) {
            mLayout.setVisibility(View.GONE);
        }
        mBannerView.setData(homeBean.getData().getBanner());
        mArrivalsView.setData(homeBean.getData().getNew_arrivals());
        mCommoditiesView.setData(homeBean.getData().getRecommend());

        mList.clear();
        mList.addAll(homeBean.getData().getGoods_list());
        mHomeAdapter.notifyDataSetChanged();

    }

    public void closeRefreshView() {
        mSpringList.setEnable(true);
        mSpringList.onFinishFreshAndLoad();
    }

    @Override
    public void onItemOnclick(View v, int position) {
        String mUrl = AppNetConfig.WEB_URL + "goodsdetail?goods_id=" + mList.get(position-3).getGoods_id() + "&";
        Bundle bundle = new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
        bundle.putString(AppConfig.WEB_TITLE, "Commodity details");

        jumpActivity(bundle, WebActivity.class);
    }

    View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.ly_arrivals_more:
                    EventBus.getDefault().post(new EventIntentFree(1));
                    break;
                case R.id.ly_commodities_more:
                    EventBus.getDefault().post(new EventIntentFree(2));
                    break;
            }

        }
    };

    @OnClick(R.id.ly_search)
    public void onViewClicked() {
        jumpActivity(null, SearchActivity.class);

    }
}
