package com.yzwuhen.abroadproject.ui.activity;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.UserBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventPage;
import com.yzwuhen.abroadproject.bean.eventBus.EventUserInfo;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.RegistSuccessPresenter;

import org.greenrobot.eventbus.EventBus;

import butterknife.Bind;

/**
 * Created by yz_wuhen on 2019/10/7/007.
 */

public class RegisterSuccessActivity extends BaseActivity<UserBean> {

    @Bind(R.id.tv_seconds)
    TextView mTvSeconds;
    private int sTime = 5;
    private RegistSuccessPresenter mPresenter;
    private String mToken;
//    Handler handler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//            sTime--;
//            if (mTvSeconds!=null){
//                mTvSeconds.setText(String.valueOf(sTime)+"Senconds");
//                if (sTime>0){
//                    handler.sendEmptyMessageDelayed(1,1000);
//                }else {
//                    EventBus.getDefault().post(new EventPage(2));
//                    handler.removeCallbacksAndMessages(null);
//                    finish();
//                }
//            }
//
//        }
//    };

    @Override
    protected void initView() {
        super.initView();


      //  handler.sendEmptyMessage(1);
        mToken =getIntent().getStringExtra(AppConfig.Token);
        mPresenter.getUserInfo(mToken);
        mPresenter.getShareLine(mToken);
    }

    @Override
    public void bindDataToView(UserBean userBean) {

        if (userBean.getError_code()==0){
            EventBus.getDefault().post(new EventUserInfo());
           finish();
        }else {
            jumpActivity(null,LoginAndReister.class);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.actiivty_reg_successed;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter =new RegistSuccessPresenter(this);
    }


}
