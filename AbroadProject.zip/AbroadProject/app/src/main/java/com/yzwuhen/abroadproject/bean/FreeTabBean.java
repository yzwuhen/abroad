package com.yzwuhen.abroadproject.bean;

import com.yzwuhen.abroadproject.ui.data.FreeTabData;

import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class FreeTabBean extends NetBean {

    /**
     * data : {"list":[{"type_id":1,"title":"测试分类1"},{"type_id":2,"title":"测试分类7"}]}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private List<FreeTabData> list;

        public List<FreeTabData> getList() {
            return list;
        }

        public void setList(List<FreeTabData> list) {
            this.list = list;
        }


    }
}
