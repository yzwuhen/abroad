package com.yzwuhen.abroadproject.base;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


import com.yz.base.BaseView;
import com.yzwuhen.abroadproject.R;

import butterknife.ButterKnife;


/**
 * Created by yz_wuhen on 2017/8/25.
 */

public abstract class BaseFragment<T> extends Fragment implements BaseView<T> {
    protected View view;

    protected BasePresenter presenter;
    FrameLayout mContanier;
    StateView mLoading;

    protected Context mContext;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //与activity一样
        // =  =貌似跟activity的stateView重叠了
        view = View.inflate(getContext(), R.layout.activity_base, null);
        mContext = getContext();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContanier = getView(R.id.contanier);
        mLoading = getView(R.id.loading);
        presenter = getPresenter();
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        mContanier.addView(View.inflate(getContext(), getLayoutId(), null), layoutParams);
        ButterKnife.bind(this, view);
        initView();
    }

    protected void initView() {
    }



    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initListener();
        initData();
    }

    protected void initListener() {
    }

    protected void initData() {

        if (presenter != null) {
            presenter.initRefreshData();
        } else {
            showSuccessView();
        }
    }

    public void setTitleHeight(LinearLayout lystateTop){
            //只兼容5.0以上
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) lystateTop.getLayoutParams();
                //  layoutParams.setMargins(0, getstateH(), 0, 0);
                layoutParams.height = layoutParams.height+getstateH();
                lystateTop.setLayoutParams(layoutParams);
                lystateTop.setPadding(0, getstateH(), 0, 0);
            }

    }

    public int getstateH() {
        try {
            Class<?> clazz = Class.forName("com.android.internal.R$dimen");
            Object object = clazz.newInstance();
            int height = Integer.parseInt(clazz.getField("status_bar_height").get(object).toString());
            return getResources().getDimensionPixelSize(height);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 50;
    }

    /**
     * 跳转到其他界面
     */
    public void jumpActivity(Bundle bundle,
                             @SuppressWarnings("rawtypes") Class targetActivity) {
        Intent intent = new Intent();
        intent.setClass(mContext, targetActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }
    /**
     * @param viewId 根据id获取view对象
     * @return
     */
    @SuppressWarnings("unchecked")
    protected <T extends View> T getView(int viewId) {
        return (T) view.findViewById(viewId);
    }


    @Override
    public void showLoadingView() {
        mLoading.setLoading();
    }

    @Override
    public void showSuccessView() {
        if (mLoading!=null)
        mLoading.hidView();
    }

    @Override
    public void bindMoreDataToView(T t) {

    }
    /**
     * 关闭网络数据加载布局
     */
    protected void closeProgressView() {
        mLoading.hidView();
        mContanier.setVisibility(View.VISIBLE);
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);

    }
    public void hintKeyBoard() {

        InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        View v = getActivity().getWindow().peekDecorView();
        if (null != v) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }

    }

    protected abstract int getLayoutId();

    public abstract BasePresenter getPresenter();


}
