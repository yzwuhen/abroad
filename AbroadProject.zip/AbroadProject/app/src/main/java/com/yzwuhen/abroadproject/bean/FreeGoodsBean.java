package com.yzwuhen.abroadproject.bean;

import com.google.gson.annotations.SerializedName;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;

import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class FreeGoodsBean extends NetBean {

    /**
     * data : {"list":[{"goods_id":6,"preview":"http://47.103.28.192/assets/upload/client/201909/login-bg.jpg","title":"测试商品 6","abstract":"","price":6025,"stock":0},{"goods_id":5,"preview":"http://47.103.28.192/assets/upload/client/201909/login-bg.jpg","title":"测试商品 5","abstract":"","price":6025,"stock":0},{"goods_id":2,"preview":"http://47.103.28.192/assets/upload/client/201909/login-bg.jpg","title":"测试商品 2","abstract":"","price":6025,"stock":0},{"goods_id":1,"preview":"http://47.103.28.192/assets/upload/client/201909/login-bg.jpg","title":"测试商品","abstract":"","price":6025,"stock":10}]}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private List<GoodsListData> list;

        public List<GoodsListData> getList() {
            return list;
        }

        public void setList(List<GoodsListData> list) {
            this.list = list;
        }

    }
}
