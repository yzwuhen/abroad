package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.HotKeyData;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class HotSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private VhOnItemClickListener mItemClickListener;
    private List<HotKeyData> mHotKeyDataList;

    public HotSearchAdapter(Context context, List<HotKeyData> listBeen, VhOnItemClickListener vhOnItemClickListener) {
        this.mContext =context;
        this.mHotKeyDataList =listBeen;
        this.mItemClickListener =vhOnItemClickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.item_search_hot, null);
        return new HotSearchVh(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        HotSearchVh hotSearchVh = (HotSearchVh) holder;
        hotSearchVh.mTvText.setText(mHotKeyDataList.get(position).getKeyword());
    }

    @Override
    public int getItemCount() {
        return mHotKeyDataList.size();
    }

    public class HotSearchVh extends RecyclerView.ViewHolder {
        @Bind(R.id.tv_hottest)
        TextView mTvText;
        public HotSearchVh(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            mTvText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(mTvText,getAdapterPosition());
                }
            });

        }
    }

}
