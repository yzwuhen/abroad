package com.yzwuhen.abroadproject.bean;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class ShareBean extends NetBean {

    /**
     * data : {"invite_code":"3P7IE9"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * invite_code : 3P7IE9
         */

        private String invite_code;


        private String invite_url;
        public String getInvite_code() {
            return invite_code;
        }

        public void setInvite_code(String invite_code) {
            this.invite_code = invite_code;
        }
        public String getInvite_url() {
            return invite_url;
        }

        public void setInvite_url(String invite_url) {
            this.invite_url = invite_url;
        }

    }
}
