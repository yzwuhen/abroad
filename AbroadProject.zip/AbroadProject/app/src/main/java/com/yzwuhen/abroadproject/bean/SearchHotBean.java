package com.yzwuhen.abroadproject.bean;

import com.yzwuhen.abroadproject.ui.data.HotKeyData;

import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class SearchHotBean extends NetBean {

    /**
     * data : {"list":[{"keyword":"banner"}]}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private List<HotKeyData> list;

        public List<HotKeyData> getList() {
            return list;
        }

        public void setList(List<HotKeyData> list) {
            this.list = list;
        }


    }
}
