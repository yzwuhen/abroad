package com.yzwuhen.abroadproject.bean.eventBus;

public class EventMsg {
    private int num;

    public EventMsg(int new_msg) {
        this.num =new_msg;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
