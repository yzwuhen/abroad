package com.yzwuhen.abroadproject.ui.data;

import android.text.TextUtils;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class UserData {
    /**
     * username : 920375741@qq.com
     * nickname :
     * sex : 0
     * head_img :
     * birthday :
     */

    private String username;
    private String nickname;
    private int sex;
    private String head_img;
    private String birthday;
    private int file_id;

    public int getFile_id() {
        return file_id;
    }

    public void setFile_id(int file_id) {
        this.file_id = file_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return TextUtils.isEmpty(nickname)?"暂无":nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getSex() {
        return sex==0?"Secrecy":(sex==1?"Male":"Female");
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getHead_img() {
        return head_img;
    }

    public void setHead_img(String head_img) {
        this.head_img = head_img;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
}
