package com.yzwuhen.abroadproject.ui.view;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;

import com.yzwuhen.abroadproject.App;

public class InterceptUrlSpan extends ClickableSpan {
    private String url;

    public InterceptUrlSpan(String url) {
        this.url = url;
    }

    @Override
    public void onClick(View arg0) {
        //此处填写对应的点击跳转逻辑
        Log.v("sssss","ssssssssssssss点击跳转");
        Intent data=new Intent(Intent.ACTION_SENDTO);
        data.setData(Uri.parse("mailto:service@unguya.com"));
        data.putExtra(Intent.EXTRA_SUBJECT, "");
        data.putExtra(Intent.EXTRA_TEXT, "");
        App.getInstance().getApplicationContext().startActivity(data);
    }

    @Override
    public void updateDrawState(TextPaint ds) {
        ds.setColor(Color.BLUE);
    }
}
