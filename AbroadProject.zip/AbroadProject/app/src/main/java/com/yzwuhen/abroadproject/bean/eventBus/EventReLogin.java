package com.yzwuhen.abroadproject.bean.eventBus;

public class EventReLogin {
}
