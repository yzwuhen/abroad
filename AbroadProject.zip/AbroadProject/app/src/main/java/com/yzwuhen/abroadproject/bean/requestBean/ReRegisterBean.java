package com.yzwuhen.abroadproject.bean.requestBean;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class ReRegisterBean extends BaseRequestBean {
    private String type="register";//forget 用不上
    private String email;//同username

    //注册时才用上
    private String password;
    private String verify_code;
    private String agreement;
    private String invite_code;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVerify_code() {
        return verify_code;
    }

    public void setVerify_code(String verify_code) {
        this.verify_code = verify_code;
    }

    public String getAgreement() {
        return agreement;
    }

    public void setAgreement(String agreement) {
        this.agreement = agreement;
    }

    public String getInvite_code() {
        return invite_code;
    }

    public void setInvite_code(String invite_code) {
        this.invite_code = invite_code;
    }
}
