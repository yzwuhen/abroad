package com.yzwuhen.abroadproject.ui.netiml;

import com.yz.net.Net;
import com.yz.net.RetrofitUtil;
import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.bean.FreeTabBean;
import com.yzwuhen.abroadproject.bean.GetCodeBean;
import com.yzwuhen.abroadproject.bean.HomeBean;
import com.yzwuhen.abroadproject.bean.MsgBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.RegisterBean;
import com.yzwuhen.abroadproject.bean.SearchHotBean;
import com.yzwuhen.abroadproject.bean.ShareBean;
import com.yzwuhen.abroadproject.bean.ShareInfoBean;
import com.yzwuhen.abroadproject.bean.UserBean;
import com.yzwuhen.abroadproject.bean.UserOrderStateBean;
import com.yzwuhen.abroadproject.bean.VistorBean;
import com.yzwuhen.abroadproject.bean.requestBean.BaseRequestBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReFreeGoodsBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReLoginBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReRegisterBean;
import com.yzwuhen.abroadproject.ui.UpLoadFileBean;
import com.yzwuhen.abroadproject.ui.data.UserData;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */

public class HttpApiIml {

    static HttpApiIml iml;
    private HttpApiInterFace apiInterface;

    public static synchronized HttpApiIml getInstance() {
        if (iml == null) {
            synchronized (HttpApiIml.class) {
                if (iml == null) {
                    iml = new HttpApiIml();
                }
            }
        }
        return iml;
    }
//两种创建方法 防止不同IP
    public HttpApiIml create() {
        iml.apiInterface = (HttpApiInterFace) RetrofitUtil.getInstance().create(HttpApiInterFace.class);
        return iml;
    }
    public HttpApiIml create(String ip) {
        iml.apiInterface = (HttpApiInterFace) RetrofitUtil.getInstanceUrl(ip).create(HttpApiInterFace.class);
        return iml;
    }

    public void  getVisitorId(BaseRequestBean baseRequestBean,Subscriber<VistorBean> subscriber){

        apiInterface.getVisitorId(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getCode(ReRegisterBean reRegisterBean, Subscriber<GetCodeBean> subscriber){

        apiInterface.getCode(reRegisterBean.getReq_source(),reRegisterBean.getSign(),reRegisterBean.getTimestamp(),reRegisterBean.getToken(),
                reRegisterBean.getVisitor_id(),
                reRegisterBean.getType(),reRegisterBean.getEmail())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  register(ReRegisterBean reRegisterBean, Subscriber<RegisterBean> subscriber){

        apiInterface.register(reRegisterBean.getReq_source(),reRegisterBean.getSign(),reRegisterBean.getTimestamp(),reRegisterBean.getToken(),
                reRegisterBean.getVisitor_id(),
                reRegisterBean.getEmail(),reRegisterBean.getPassword(),reRegisterBean.getVerify_code(),reRegisterBean.getAgreement(),reRegisterBean.getInvite_code())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  login(ReLoginBean mLoginBean, Subscriber<RegisterBean> subscriber){

        apiInterface.login(mLoginBean.getReq_source(),mLoginBean.getSign(),mLoginBean.getTimestamp(),mLoginBean.getToken(),
                mLoginBean.getVisitor_id(),
                mLoginBean.getUsername(),mLoginBean.getPassword())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  loginOut(ReLoginBean mLoginBean, Subscriber<RegisterBean> subscriber){

        apiInterface.loginOut(mLoginBean.getReq_source(),mLoginBean.getSign(),mLoginBean.getTimestamp(),mLoginBean.getToken(),
                mLoginBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  getUserInfo(ReLoginBean mLoginBean, Subscriber<UserBean> subscriber){

        apiInterface.getUserInfo(mLoginBean.getReq_source(),mLoginBean.getSign(),mLoginBean.getTimestamp(),mLoginBean.getToken(),
                mLoginBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }


    public void  getFreeTab(ReFreeGoodsBean freeGoodsBean, Subscriber<FreeTabBean> subscriber){

        apiInterface.getFreeTab(freeGoodsBean.getReq_source(),freeGoodsBean.getSign(),freeGoodsBean.getTimestamp(),freeGoodsBean.getToken(),freeGoodsBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getFreeGoods(ReFreeGoodsBean freeGoodsBean, Subscriber<FreeGoodsBean> subscriber){

        apiInterface.getFreeGoodsList(freeGoodsBean.getReq_source(),freeGoodsBean.getSign(),freeGoodsBean.getTimestamp(),freeGoodsBean.getToken(),freeGoodsBean.getVisitor_id(),
                freeGoodsBean.getType_id(),freeGoodsBean.getSearch(),freeGoodsBean.getOrder_by(),freeGoodsBean.getPage(),freeGoodsBean.getLimit())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getHomeList(BaseRequestBean baseRequestBean, Subscriber<HomeBean> subscriber){

        apiInterface.getHomeList(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }


    public void  getLoginShareLine(ReLoginBean reLoginBean, Subscriber<ShareBean> subscriber){

        apiInterface.getShareLine(reLoginBean.getReq_source(),reLoginBean.getSign(),reLoginBean.getTimestamp(),reLoginBean.getToken(),reLoginBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getUserOrder(ReLoginBean reLoginBean, Subscriber<UserOrderStateBean> subscriber){

        apiInterface.getOrder(reLoginBean.getReq_source(),reLoginBean.getSign(),reLoginBean.getTimestamp(),reLoginBean.getToken(),reLoginBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }



    public void  getShareLine(BaseRequestBean baseRequestBean, Subscriber<ShareBean> subscriber){

        apiInterface.getShareLine(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }


    public void  getShareInfo(BaseRequestBean baseRequestBean, Subscriber<ShareInfoBean> subscriber){

        apiInterface.getShareInfo(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getHotList(BaseRequestBean baseRequestBean, Subscriber<SearchHotBean> subscriber){

        apiInterface.getHotList(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    /*
    *
    * 上传文件
    * */
    public void uploadUserImage(MultipartBody.Part body, RequestBody token, RequestBody timestamp, RequestBody req_source, RequestBody visitor_id, RequestBody sgin, RequestBody block, Subscriber<UpLoadFileBean> subscriber) {
        apiInterface.uploadFile(body,
                req_source,sgin,timestamp,token,visitor_id,block)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  upDataHeadPic(BaseRequestBean baseRequestBean,int file_id, Subscriber<NetBean> subscriber){

        apiInterface.upDatePic(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id(),file_id)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  upDataBirth(BaseRequestBean baseRequestBean,String years,String month,String day, Subscriber<NetBean> subscriber){

        apiInterface.upDateBirth(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id(),years,month,day)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  upDataSex(BaseRequestBean baseRequestBean,int sex, Subscriber<NetBean> subscriber){

        apiInterface.upDateSex(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id(),sex)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  upDataNick(BaseRequestBean baseRequestBean,String nick, Subscriber<NetBean> subscriber){

        apiInterface.upDateNick(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id(),nick)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public void  getMsg(BaseRequestBean baseRequestBean,Subscriber<MsgBean> subscriber){

        apiInterface.getMsg(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public void  deleteMsg(BaseRequestBean baseRequestBean,Subscriber<NetBean> subscriber){

        apiInterface.delete(baseRequestBean.getReq_source(),baseRequestBean.getSign(),baseRequestBean.getTimestamp(),baseRequestBean.getToken(),
                baseRequestBean.getVisitor_id())
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
}
