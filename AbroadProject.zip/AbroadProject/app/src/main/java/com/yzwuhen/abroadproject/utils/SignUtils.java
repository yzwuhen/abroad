package com.yzwuhen.abroadproject.utils;

import android.support.annotation.NonNull;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.Log;

import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class SignUtils {

    public static String sign(Map<String, String> map) {
        if (map == null) {
            return null;
        }
        List<String> keyList = new ArrayList<>(map.keySet());
        Collections.sort(keyList);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < keyList.size(); i++) {
            String key = keyList.get(i);
            Object value = URLEncoder.encode(map.get(key));
            sb.append(key + "=" + value + "&");
        }
        String signStr = sb.substring(0, sb.length() - 1);
        Log.v("ssssss","before sign: " + signStr);
        String md5Str = md5(signStr);
        Log.v("ssssss","after sign: " + md5Str);
        return md5Str;

    }

    @NonNull
    public static String md5(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
            byte[] bytes = md5.digest(string.getBytes());
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) {
                String temp = Integer.toHexString(b & 0xff);
                if (temp.length() == 1) {
                    temp = "0" + temp;
                }
                result.append(temp);
            }
            return result.toString();
          //  return result.toString().substring(8,24)；   //16位
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
    //邮箱格式判断
    public static boolean isEmail(String email){
        if (null==email || "".equals(email)) return false;
        //Pattern p = Pattern.compile("\\w+@(\\w+.)+[a-z]{2,3}"); //简单匹配
        Pattern p =  Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");//复杂匹配
        Matcher m = p.matcher(email);
        return m.matches();
    }

    /**
     * double转String,保留小数点后两位
     * @param num
     * @return
     */
    public static String doubleToString(double num){
        //使用0.00不足位补0，#.##仅保留有效位
        double nums =num/100;

        return new DecimalFormat("0.00").format(nums);
    }
    /**
     * double转String,不保留小数点
     * @param num
     * @return
     */
    public static String doubleToStrings(double num){
        //使用0.00不足位补0，#.##仅保留有效位
        double nums =num/100;

        return new DecimalFormat("0").format(nums);
    }
    public static SpannableString bigText(String text){

        SpannableString spannableString = new SpannableString(text);
        RelativeSizeSpan sizeSpan01 = new RelativeSizeSpan(0.8f);
        if (text.contains("$")){
            RelativeSizeSpan sizeSpan02 = new RelativeSizeSpan(0.8f);
            spannableString.setSpan(sizeSpan02, text.indexOf("$"), text.indexOf("$")+1, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        }
        spannableString.setSpan(sizeSpan01, text.length()-3, text.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);

        return spannableString;
    }

}
