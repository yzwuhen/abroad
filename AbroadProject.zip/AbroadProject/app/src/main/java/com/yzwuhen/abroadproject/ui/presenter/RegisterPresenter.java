package com.yzwuhen.abroadproject.ui.presenter;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.GetCodeBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.RegisterBean;
import com.yzwuhen.abroadproject.bean.ShareBean;
import com.yzwuhen.abroadproject.bean.UserBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReLoginBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReRegisterBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class RegisterPresenter extends BasePresenterIml<NetBean> {
    ReRegisterBean mReRegisterBean= new ReRegisterBean();

    public RegisterPresenter(BaseView baseView) {
        super(baseView);
    }

    @Override
    public void showErrorStateView() {

    }

    @Override
    protected void requestNetData() {

    }


    public void getCode(String email){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token","");
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("type","register");
        map.put("email",email);

        mReRegisterBean.setSign(SignUtils.sign(map));
        mReRegisterBean.setTimestamp(map.get("timestamp"));
        mReRegisterBean.setEmail(email);
        mReRegisterBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().getCode(mReRegisterBean,new NetSubscriber<GetCodeBean>(new SubscriberListener<GetCodeBean>(baseView) {
            @Override
            public void onNext(GetCodeBean getCodeBean) {
                if (getCodeBean.getError_code()==0){
                    ToastUtils.showMsg(getCodeBean.getError_msg());
                }else {
                    ToastUtils.showMsg(getCodeBean.getError_msg());
                }

            }
        }));
    }

    public void regist(String email,String code,String pwd,String invitaCode,boolean isCheck){

        Map<String,String> map= new HashMap<String,String>();
        map.put("token","");
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("username",email);
        map.put("password",SignUtils.md5(pwd));
        map.put("verify_code",code);
        map.put("agreement",isCheck?"1":"2");
        map.put("invite_code", invitaCode);

        mReRegisterBean.setSign(SignUtils.sign(map));
        mReRegisterBean.setTimestamp(map.get("timestamp"));
        mReRegisterBean.setEmail(email);
        mReRegisterBean.setVerify_code(code);
        mReRegisterBean.setPassword(SignUtils.md5(pwd));
        mReRegisterBean.setInvite_code(invitaCode);
        mReRegisterBean.setAgreement(isCheck?"1":"2");
        mReRegisterBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));



        HttpApiIml.getInstance().create().register(mReRegisterBean,new NetSubscriber<RegisterBean>(new SubscriberListener<RegisterBean>(baseView) {
            @Override
            public void onNext(RegisterBean netBean) {
                if (netBean.getError_code()==0){
                    Hawk.put(AppConfig.Token,netBean.getData().getToken());
                    bindDataToView(netBean);
                }else {
                    ToastUtils.showMsg(netBean.getError_msg());
                }
            }
        }));
    }



    @Override
    protected void loadChildMoreNetData() {

    }
}
