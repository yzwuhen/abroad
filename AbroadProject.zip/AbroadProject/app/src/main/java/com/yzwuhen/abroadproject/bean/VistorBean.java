package com.yzwuhen.abroadproject.bean;

import com.yzwuhen.abroadproject.ui.data.VisitorData;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class VistorBean extends NetBean {

    /**
     * data : {"visitor_id":"nK25VnAUCT/HIJxq1c/PDbuZgHU/eXk/"}
     */

    private VisitorData data;

    public VisitorData getData() {
        return data;
    }

    public void setData(VisitorData data) {
        this.data = data;
    }

}
