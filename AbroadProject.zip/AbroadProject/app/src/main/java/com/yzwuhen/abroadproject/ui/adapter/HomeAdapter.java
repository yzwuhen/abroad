package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;
import com.yzwuhen.abroadproject.ui.fragment.HomeFragment;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.ui.widget.ArrivalsView;
import com.yzwuhen.abroadproject.ui.widget.BannerView;
import com.yzwuhen.abroadproject.ui.widget.CommoditiesView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;
import com.yzwuhen.abroadproject.utils.SignUtils;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class HomeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private List<View> mViews;
    private List<GoodsListData> mList;
    private VhOnItemClickListener mItemClickListener;
    private BannerView mBannerView;
    private ArrivalsView mArrivalsView;
    private CommoditiesView mCommoditiesView;

    public HomeAdapter(Context context, List<GoodsListData> list, BannerView bannerView, ArrivalsView arrivalsView, CommoditiesView commoditiesView, VhOnItemClickListener vhOnItemClickListener) {
        this.mContext =context;
        this.mList = list;
        this.mItemClickListener =vhOnItemClickListener;
        this.mBannerView =bannerView;
        this.mArrivalsView =arrivalsView;
        this.mCommoditiesView =commoditiesView;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewType ==0){
            return  new BannerVH(mBannerView);
        }
        else if (viewType ==1){
            return new ArrivalsVH(mArrivalsView);
        }
        else if (viewType ==2){
            return new CommoditiesVH(mCommoditiesView);
        }
        else {
            View view = View.inflate(mContext,R.layout.item_home_goods,null);
            return new HomeVH(view);

        }

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (position>2){
            HomeVH homeVH = (HomeVH) holder;

            String ss ="$"+mList.get(position-3).getPrice();

            homeVH.mTvCostPrice.setText(SignUtils.bigText(ss));
            homeVH.mTvCostPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG );
            homeVH.mTvPrice.setText(SignUtils.bigText("0.00"));
            homeVH.mTvGoodsName.setText(mList.get(position-3).getTitle());
            ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),homeVH.mIvPic,mList.get(position-3).getPreview(),R.mipmap.goods_defult);


        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        RecyclerView.LayoutManager manager =recyclerView.getLayoutManager();
        if (manager == null || !(manager instanceof GridLayoutManager))return;
        final GridLayoutManager gridLayoutManager = (GridLayoutManager) manager;
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (getItemViewType(position)<3){
                    return gridLayoutManager.getSpanCount();
                }
                return 1;
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size()==0?3:(mList.size()+3);
    }
    public class BannerVH extends RecyclerView.ViewHolder{

        public BannerVH(View itemView) {
            super(itemView);

        }

    }
    public class ArrivalsVH extends RecyclerView.ViewHolder{
        public ArrivalsVH(View itemView) {
            super(itemView);
        }

    }
    public class CommoditiesVH extends RecyclerView.ViewHolder{

        public CommoditiesVH(View itemView) {
            super(itemView);
        }

    }

    public class HomeVH extends RecyclerView.ViewHolder{

        @Bind(R.id.iv_pic)
        CusImageView mIvPic;
        @Bind(R.id.tv_goods_name)
        TextView mTvGoodsName;
        @Bind(R.id.tv_price)
        TextView mTvPrice;
        @Bind(R.id.tv_cost_price)
        TextView mTvCostPrice;

        public HomeVH(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mItemClickListener.onItemOnclick(v, getAdapterPosition());

                    }
                });

        }

    }
}
