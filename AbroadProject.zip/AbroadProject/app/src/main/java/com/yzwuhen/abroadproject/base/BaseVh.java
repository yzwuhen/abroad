package com.yzwuhen.abroadproject.base;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.yzwuhen.abroadproject.allinterface.VhOnItemOnClickListener;


/**
 * Created by yz_wuhen on 2017/12/4.
 */

public class BaseVh extends RecyclerView.ViewHolder {

    public BaseVh(View itemView) {
        super(itemView);

    }

    public BaseVh(View view, final VhOnItemOnClickListener vhOnItemOnClickListener) {
        super(view);
        if (vhOnItemOnClickListener != null) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vhOnItemOnClickListener.onItemClick(v, getAdapterPosition());

                }
            });
        }
    }


}
