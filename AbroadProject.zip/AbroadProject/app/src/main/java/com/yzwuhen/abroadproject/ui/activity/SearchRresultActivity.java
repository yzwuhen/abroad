package com.yzwuhen.abroadproject.ui.activity;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.liaoinstan.springview.widget.SpringView;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.ui.adapter.FreeGoodsAdapter;
import com.yzwuhen.abroadproject.ui.data.GoodsListData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.SearchGoodsPresenter;
import com.yzwuhen.abroadproject.ui.widget.GridItemDecoration;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class SearchRresultActivity extends BaseActivity<FreeGoodsBean> implements VhOnItemClickListener{
    @Bind(R.id.tv_search_str)
    TextView mTvSearchStr;
    @Bind(R.id.et_search)
    EditText mEtSearch;
    @Bind(R.id.iv_close)
    ImageView mIvClose;
    @Bind(R.id.iv_search)
    ImageView mIvSearch;
    @Bind(R.id.ly_search)
    LinearLayout mLySearch;
    @Bind(R.id.tv_cancel)
    TextView mTvCancel;
    @Bind(R.id.tv_newest)
    TextView mTvNewest;
    @Bind(R.id.ly_newest)
    LinearLayout mLyNewest;
    @Bind(R.id.tv_hottest)
    TextView mTvHottest;
    @Bind(R.id.ly_hottest)
    LinearLayout mLyHottest;
    @Bind(R.id.tv_value)
    TextView mTvValue;
    @Bind(R.id.ly_value)
    LinearLayout mLyValue;
    @Bind(R.id.recycle_list)
    RecyclerView mRecycleList;
    @Bind(R.id.spring_list)
    SpringView mSpringList;


    private List<GoodsListData> mDataList;
    private FreeGoodsAdapter mGoodsAdapter;

    private List<TextView> mTextViews;
    private String mStrKey;//搜索的关键词
    private String orderBy="newest";//排序  newest： 最新商品  price： 价格排序 hottest： 最热商品
    private int page;

    private SearchGoodsPresenter mPresenter;
    @Override
    protected void initView() {
        super.initView();

        mDataList=  new ArrayList<>();



        mGoodsAdapter = new FreeGoodsAdapter(this,mDataList,this);
        GridItemDecoration divider = new GridItemDecoration.Builder(this)
                .setHorizontalSpan(R.dimen.dp_10)
                .setVerticalSpan(R.dimen.dp_10)
                .setColorResource(R.color.carview_color)
                .setShowLastLine(true)
                .build();
        mRecycleList.addItemDecoration(divider);
        mRecycleList.setLayoutManager(new GridLayoutManager(this,2));

        mRecycleList.setAdapter(mGoodsAdapter);

        mTextViews=  new ArrayList<>();

        mTextViews.add(mTvNewest);
        mTextViews.add(mTvHottest);
        mTextViews.add(mTvValue);

        mTextViews.get(0).setSelected(true);

        mTvSearchStr.setText(mStrKey+" ");



        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getTexts();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mEtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId==3){
                    searchText();
                }


                return false;
            }
        });

        setSpringStyle();
        initListener();
    }

    private void getTexts() {
        mStrKey =mEtSearch.getText().toString().trim();
        if (TextUtils.isEmpty(mStrKey)){
            mIvClose.setVisibility(View.GONE);
        }else {
            mIvClose.setVisibility(View.VISIBLE);
        }

    }

    private void initListener() {
        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                closeProgressView();
                initPresenter();
            }

            @Override
            public void onLoadmore() {
                mSpringList.setEnable(false);
                closeProgressView();
                if(presenter==null){
                    showSuccessView();
                }else{
                    presenter.loadMoreNetData();
                }
            }
        });
    }
    protected void setSpringStyle(){
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(this));
        mSpringList.setFooter(RefreshHeaderUtils.getFooterView(this));
    }
    private void searchText() {
        mPresenter.getGoodsList(mStrKey,orderBy,page, AppConfig.Limit);

    }

    @Override
    public void bindDataToView(FreeGoodsBean freeGoodsBean) {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_search_result;
    }

    @Override
    public BasePresenter getPresenter() {
        mStrKey = getIntent().getStringExtra("key");
        return mPresenter=new SearchGoodsPresenter(this,mStrKey);
    }


    public void changeOrder(int index){

        for (int i=0;i<mTextViews.size();i++){
            if (i==index){
                mTextViews.get(index).setSelected(true);
            }
            else {
                mTextViews.get(i).setSelected(false);
            }
        }

    }

    @OnClick({R.id.tv_search_str, R.id.ly_search, R.id.tv_cancel, R.id.ly_newest, R.id.ly_hottest, R.id.ly_value,R.id.iv_close})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_search_str:
                mTvSearchStr.setVisibility(View.GONE);
                mEtSearch.setVisibility(View.VISIBLE);
                break;
            case R.id.ly_search:
                mTvSearchStr.setVisibility(View.GONE);
                mEtSearch.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_cancel:
                finish();
                break;
            //排序  newest： 最新商品  price： 价格排序 hottest： 最热商品
            case R.id.ly_newest:
                orderBy ="newest";
                page =0;
                searchText();
                changeOrder(0);
                break;
            case R.id.ly_hottest:
                orderBy ="price";
                page =0;
                searchText();
                changeOrder(1);
                break;
            case R.id.ly_value:
                orderBy ="hottest";
                page =0;
                searchText();
                changeOrder(2);
                break;
            case R.id.iv_close:
                mEtSearch.setText("");
                break;
        }
    }

    @Override
    public void onItemOnclick(View v, int position) {

        String mUrl = AppNetConfig.WEB_URL + "goodsdetail?goods_id=" + mDataList.get(position).getGoods_id() + "&";
        Bundle bundle = new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
        bundle.putString(AppConfig.WEB_TITLE, "Commodity details");
        jumpActivity(bundle, WebActivity.class);
    }
    public void closeRefreshView() {
        mSpringList.setEnable(true);
        mSpringList.onFinishFreshAndLoad();
    }

    public void upData(FreeGoodsBean netBean, int pages) {

        closeRefreshView();
        if (netBean.getError_code()==0){
            //说明是刷新数据
            if (pages==0){
                mDataList.clear();
                mDataList.addAll(netBean.getData().getList());
                mGoodsAdapter.notifyDataSetChanged();
            }else {
                mDataList.addAll(netBean.getData().getList());
                mGoodsAdapter.notifyItemChanged(mDataList.size());
            }
        }

    }
}
