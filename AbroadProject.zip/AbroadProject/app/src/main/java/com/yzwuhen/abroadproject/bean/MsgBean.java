package com.yzwuhen.abroadproject.bean;

/**
 * Created by yz_wuhen on 2019/10/13/013.
 */

public class MsgBean extends NetBean {


    /**
     * data : {"push_title":"这里是精选推送标题 1569030285","system_title":"","access_title":""}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * push_title : 这里是精选推送标题 1569030285
         * system_title :
         * access_title :
         */

        private String push_title;
        private String system_title;
        private String access_title;
        private int system_read_status;
        private int access_read_status;

        public String getPush_title() {
            return push_title;
        }

        public void setPush_title(String push_title) {
            this.push_title = push_title;
        }

        public String getSystem_title() {
            return system_title;
        }

        public void setSystem_title(String system_title) {
            this.system_title = system_title;
        }

        public String getAccess_title() {
            return access_title;
        }

        public void setAccess_title(String access_title) {
            this.access_title = access_title;
        }

        public int getSystem_read_status() {
            return system_read_status;
        }

        public void setSystem_read_status(int system_read_status) {
            this.system_read_status = system_read_status;
        }

        public int getAccess_read_status() {
            return access_read_status;
        }

        public void setAccess_read_status(int access_read_status) {
            this.access_read_status = access_read_status;
        }
    }
}
