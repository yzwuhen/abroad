package com.yzwuhen.abroadproject.bean.requestBean;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class BaseRequestBean {

    public String token="";
    public String timestamp;
    public String sign;
    public String req_source="android";//android
    public String visitor_id;
    public String sign_type;
    public String version;//1.0.0

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getReq_source() {
        return req_source;
    }

    public void setReq_source(String req_source) {
        this.req_source = req_source;
    }

    public String getVisitor_id() {
        return visitor_id;
    }

    public void setVisitor_id(String visitor_id) {
        this.visitor_id = visitor_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
