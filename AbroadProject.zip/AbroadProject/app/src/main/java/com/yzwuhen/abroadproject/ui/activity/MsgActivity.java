package com.yzwuhen.abroadproject.ui.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.MsgBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventMsg;
import com.yzwuhen.abroadproject.ui.adapter.MsgAdapter;
import com.yzwuhen.abroadproject.ui.data.MsgData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.MsgPresenter;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class MsgActivity extends BaseActivity<MsgBean> implements VhOnItemClickListener {

    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.rv_list)
    RecyclerView mRvList;
    @Bind(R.id.iv_logo)
    ImageView mImageView;
    private MsgAdapter mMsgAdapter;
    private MsgPresenter mPresenter;

    private List<MsgData> mList;
    private String mUrl;
    private String mWebTitle;

    @Override
    protected void initView() {
        super.initView();

        mTvTitle.setText(getResources().getString(R.string.Message_Center));
        mList = new ArrayList<>();
        mMsgAdapter = new MsgAdapter(this, mList, this);
        mRvList.setLayoutManager(new LinearLayoutManager(this));
        mRvList.setAdapter(mMsgAdapter);

        mIvLeft.setImageResource(R.mipmap.sys_back);
        mIvRight.setImageResource(R.mipmap.sys_del);

        EventBus.getDefault().post(new EventMsg(0));
    }

    @Override
    public void bindDataToView(MsgBean netBean) {

        if (netBean.getError_code() == 0) {
            mList.clear();


            MsgData msgData = new MsgData();
            msgData.setMsg(netBean.getData().getPush_title());
            if (TextUtils.isEmpty(netBean.getData().getPush_title())){
                msgData.setStatus(0);
            }else {
                msgData.setStatus(1);
            }

            MsgData msgData1 = new MsgData();
            msgData1.setMsg(netBean.getData().getSystem_title());
            msgData1.setStatus(netBean.getData().getSystem_read_status());

            MsgData msgData2 = new MsgData();
            msgData2.setMsg(netBean.getData().getAccess_title());
            msgData2.setStatus(netBean.getData().getAccess_read_status());

            mList.add(msgData);
            mList.add(msgData1);
            mList.add(msgData2);
            mMsgAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_msg;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new MsgPresenter(this);
    }

    @OnClick({R.id.ly_left, R.id.ly_right})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
                finish();
                break;
            case R.id.ly_right:
                mPresenter.deleteMsg();
                break;
        }
    }

    @Override
    public void onItemOnclick(View v, int position) {

        if (position == 0) {
            mUrl = AppNetConfig.WEB_URL + "push?";
            mWebTitle = "Featured Push";
        } else if (position == 1) {

            mUrl = AppNetConfig.WEB_URL + "systemnotice?type=1&";
            mWebTitle = "System notification";
        } else {
            //意见反馈没做
            mUrl = AppNetConfig.WEB_URL + "systemnotice?type=2&";
            mWebTitle = "Account notification";
        }
       if (mList.size()>0){
           mList.get(position).setStatus(0);
           mMsgAdapter.notifyItemChanged(position);

       }
        junWebAct(mWebTitle);
    }

    public void junWebAct(String title) {
        Bundle bundle = new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
        bundle.putString(AppConfig.WEB_TITLE, title);
        jumpActivity(bundle, WebActivity.class);

    }

    public void deleteSucces() {

        ToastUtils.showMsg("Delete Success");
    }
}
