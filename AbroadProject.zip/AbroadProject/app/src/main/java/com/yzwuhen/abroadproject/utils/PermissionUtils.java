package com.yzwuhen.abroadproject.utils;

import android.content.pm.PackageManager;
import android.os.Build;

import com.yzwuhen.abroadproject.App;


/**
 * Created by yz_wuhen on 2017/11/14.
 */

public class PermissionUtils {

    public static boolean isGranted(String permission) {
        return !isMarshmallow() || isGranted_(permission);
    }
    private  static  boolean isMarshmallow() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }
    private static boolean isGranted_(String permission) {

        PackageManager pm = App.getInstance().getPackageManager();
        boolean permissionCode= PackageManager.PERMISSION_GRANTED ==
                pm.checkPermission(permission, "com.news.projects.newsproject");
        return permissionCode;
    }
}
