package com.yzwuhen.abroadproject.ui.netiml;

import com.yz.net.ISubscriberListener;
import com.yz.net.NetSubscriber;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventMsg;
import com.yzwuhen.abroadproject.bean.eventBus.EventReLogin;

import org.greenrobot.eventbus.EventBus;

public class NetSub<T> extends NetSubscriber<T> {
    public NetSub(ISubscriberListener<T> listener) {
        super(listener);
    }

    @Override
    public void onNext(T t) {

        super.onNext(t);

        if(t !=null){
            if(((NetBean)t).getNew_msg()>0){
                EventBus.getDefault().post(new EventMsg(((NetBean)t).getNew_msg()));
            }

        }
    }
}
