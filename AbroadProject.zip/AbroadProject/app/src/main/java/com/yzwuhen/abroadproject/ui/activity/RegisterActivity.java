package com.yzwuhen.abroadproject.ui.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.RegisterPresenter;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/7/007.
 */

public class RegisterActivity extends BaseActivity<NetBean> {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.et_email)
    EditText mEtEmail;
    @Bind(R.id.tv_get_code)
    TextView mTvGetCode;
    @Bind(R.id.et_code)
    EditText mEtCode;
    @Bind(R.id.et_pwd)
    EditText mEtPwd;
    @Bind(R.id.iv_eyes)
    ImageView mIvEyes;
    @Bind(R.id.et_invitation_code)
    EditText mEtInvitationCode;
    @Bind(R.id.iv_check)
    ImageView mIvCheck;
    @Bind(R.id.tv_agreement)
    TextView mTvAgreement;
    @Bind(R.id.tv_next)
    TextView mTvNext;
    @Bind(R.id.iv_next)
    ImageView mIvNext;

    private String msEmail,msPwd,msCode,msInviteCode;



    private boolean isOpenEye;
    private boolean isCheck =true;

    private RegisterPresenter mPresenter;
    private int sTime=60;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            sTime--;
            if (mTvGetCode!=null){
                mTvGetCode.setText(String.valueOf(sTime)+"s");
                if (sTime>0){
                    handler.sendEmptyMessageDelayed(1,1000);
                }else {
                    mTvGetCode.setText("Get Code");
                    mTvGetCode.setEnabled(true);
                    handler.removeCallbacksAndMessages(null);
                }
            }

        }
    };

    @Override
    protected void initView() {
        super.initView();
        mLyRight.setVisibility(View.INVISIBLE);
        mIvLeft.setImageResource(R.mipmap.login_close);
        mTvTitle.setText("Sign Up");

        mIvCheck.setSelected(isCheck);

        mEtEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {



            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                msEmail =mEtEmail.getText().toString().trim();
                msPwd =mEtPwd.getText().toString().trim();
                msCode =mEtCode.getText().toString().trim();
                etChange();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEtPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                msEmail =mEtEmail.getText().toString().trim();
                msPwd =mEtPwd.getText().toString().trim();
                msCode =mEtCode.getText().toString().trim();
                etChange();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEtCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                msEmail =mEtEmail.getText().toString().trim();
                msPwd =mEtPwd.getText().toString().trim();
                msCode =mEtCode.getText().toString().trim();
                etChange();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void etChange(){
        if (!TextUtils.isEmpty(msEmail)&&!TextUtils.isEmpty(msPwd)&&!TextUtils.isEmpty(msCode)){
            mTvNext.setSelected(true);
        }else {
            mTvNext.setSelected(false);
        }
    }
    @Override
    public void bindDataToView(NetBean netBean) {

        if (netBean.getError_code()==0){
                finish();
              jumpActivity(null,RegisterSuccessActivity.class);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_register;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new RegisterPresenter(this);
    }



    @OnClick({R.id.ly_left, R.id.tv_get_code, R.id.iv_eyes, R.id.tv_agreement, R.id.tv_next, R.id.iv_next,R.id.iv_check})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
                finish();
                break;
            case R.id.tv_get_code:
                msEmail =mEtEmail.getText().toString().trim();
                if (!TextUtils.isEmpty(msEmail)){
                    if (!SignUtils.isEmail(msEmail)){
                        ToastUtils.showMsg("邮箱格式错误");
                        return;
                    }
                    handler.sendEmptyMessage(1);
                    mTvGetCode.setEnabled(false);
                    mPresenter.getCode(msEmail);
                }else {
                    ToastUtils.showMsg("邮箱不能为空");
                }

                break;
            case R.id.iv_eyes:
                if(!isOpenEye) {
                    mIvEyes.setImageResource(R.mipmap.login_open_eyes);
                    isOpenEye = true;
                    //密码可见
                    mEtPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    mIvEyes.setImageResource(R.mipmap.login_close_eyes);
                    isOpenEye = false;
                    //密码不可见
                    mEtPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                break;
            case R.id.iv_check:
                isCheck =!isCheck;
                mIvCheck.setSelected(isCheck);
                break;
            case R.id.tv_agreement:
                Bundle bundle = new Bundle();
                bundle.putString(AppConfig.WEB_LOAD_URL, AppNetConfig.WEB_URL+"agreement?");
                bundle.putString(AppConfig.WEB_TITLE, "Agreement?");
                jumpActivity(bundle,WebActivity.class);
                break;
            case R.id.tv_next:
                register();

                break;
            case R.id.iv_next:
                finish();
                break;
        }
    }

    private void register() {
        msEmail =mEtEmail.getText().toString().trim();
        msPwd =mEtPwd.getText().toString().trim();
        msCode =mEtCode.getText().toString().trim();
        msInviteCode =mEtInvitationCode.getText().toString().trim();
        if (TextUtils.isEmpty(msEmail)){
            ToastUtils.showMsg("邮箱不能为空");
            return;
        }
        if (TextUtils.isEmpty(msCode)){
            ToastUtils.showMsg("验证码不能为空");
            return;
        }
        if (TextUtils.isEmpty(msPwd)){
            ToastUtils.showMsg("密码不能为空");
            return;
        }

        mPresenter.regist(msEmail,msCode,msPwd,msInviteCode,isCheck);


    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacksAndMessages(null);
    }
}
