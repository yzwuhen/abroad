package com.yzwuhen.abroadproject.ui.globle;

/**
 * Created by yz_wuhen on 2019/8/30/030.
 */

public class AppConfig {

    //用户信息表
    public static String ACCOUNT="account";
    public static String USER_INFO="user_info";
    public static String Visitor_Id="visitor_id";
    public static String Token="token";
    public static String ShareCode="share_code";
    public static String Share_URL="share_url";
    public static String HISTORY="history";
    public static String WEB_LOAD_URL="url";
    public static String WEB_TITLE="web_title";
    public static String LOGIN_PAGE_TYPE="login_page_type";
    public static int Limit=20;
}
