package com.yzwuhen.abroadproject.bean;

/**
 * Created by yz_wuhen on 2019/10/13/013.
 */

public class ShareInfoBean extends NetBean {

    /**
     * data : {"invite_code":"3P7IE9","total":0,"share_amount":"0","invite_amount":0,"profits":0}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * invite_code : 3P7IE9
         * total : 0
         * share_amount : 0
         * invite_amount : 0
         * profits : 0
         */

        private String invite_code;
        private int total;
        private String share_amount;
        private int invite_amount;
        private int profits;

        public String getInvite_code() {
            return invite_code;
        }

        public void setInvite_code(String invite_code) {
            this.invite_code = invite_code;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public String getShare_amount() {
            return share_amount;
        }

        public void setShare_amount(String share_amount) {
            this.share_amount = share_amount;
        }

        public int getInvite_amount() {
            return invite_amount;
        }

        public void setInvite_amount(int invite_amount) {
            this.invite_amount = invite_amount;
        }

        public int getProfits() {
            return profits;
        }

        public void setProfits(int profits) {
            this.profits = profits;
        }
    }
}
