package com.yzwuhen.abroadproject.ui.data;

import com.google.gson.annotations.SerializedName;
import com.yzwuhen.abroadproject.utils.SignUtils;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class NewArrivalsData {


    /**
     * goods_id : 4
     * preview : http://47.103.28.192/assets/upload/client/201909/80052019091814452493.png
     * title : 测试商品 4
     * abstract :
     * price : 6025
     */

    private int goods_id;
    private String preview;
    private String title;
    @SerializedName("abstract")
    private String abstractX;
    private double price;

    public int getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(int goods_id) {
        this.goods_id = goods_id;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAbstractX() {
        return abstractX;
    }

    public void setAbstractX(String abstractX) {
        this.abstractX = abstractX;
    }

    public String getPrice() {
        return SignUtils.doubleToString(price);
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
