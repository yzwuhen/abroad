package com.yzwuhen.abroadproject.bean;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class RegisterBean extends NetBean {

    /**
     * data : {"token":"nLKZjZQh27fYpdQdG5yeDKUMPFzYl66NsyHhWB+/cfmSovQugH"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * token : nLKZjZQh27fYpdQdG5yeDKUMPFzYl66NsyHhWB+/cfmSovQugH
         */

        private String token;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }
}
