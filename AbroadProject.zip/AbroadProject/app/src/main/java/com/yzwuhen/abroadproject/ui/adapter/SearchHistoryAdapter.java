package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.activity.SearchActivity;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class SearchHistoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private VhOnItemClickListener mItemClickListener;
    private List<String> mList;

    public SearchHistoryAdapter(Context context, List<String> historyList, VhOnItemClickListener vhOnItemClickListener) {
        this.mContext =context;
        this.mItemClickListener =vhOnItemClickListener;
        this.mList =historyList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.item_search_history, null);
        return new HistoryVh(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        HistoryVh historyVh = (HistoryVh) holder;

        historyVh.mTvText.setText(mList.get(position));
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class HistoryVh extends RecyclerView.ViewHolder {
        @Bind(R.id.tv_text)
        TextView mTvText;
        public HistoryVh(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            mTvText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(mTvText,getAdapterPosition());
                }
            });

        }
    }

}
