package com.yzwuhen.abroadproject.ui.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.liaoinstan.springview.widget.SpringView;
import com.orhanobut.hawk.Hawk;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.UserOrderStateBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventIntentFree;
import com.yzwuhen.abroadproject.bean.eventBus.EventMsg;
import com.yzwuhen.abroadproject.bean.eventBus.EventUserInfo;
import com.yzwuhen.abroadproject.ui.activity.MsgActivity;
import com.yzwuhen.abroadproject.ui.activity.SettingActivity;
import com.yzwuhen.abroadproject.ui.activity.UserInfoActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.data.UserData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.UserPresenter;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */


public class UserFragment extends BaseFragment<UserOrderStateBean> {
    @Bind(R.id.iv_user_pic)
    CusImageView mIvUserPic;
    @Bind(R.id.tv_user_name)
    TextView mTvUserName;
    @Bind(R.id.tv_email)
    TextView mTvEmail;
    @Bind(R.id.ly_audit)
    LinearLayout mLyAudit;
    @Bind(R.id.ly_wait_et)
    LinearLayout mLyWaitEt;
    @Bind(R.id.ly_wait_upload)
    LinearLayout mLyWaitUpload;
    @Bind(R.id.ly_fail)
    LinearLayout mLyFail;
    @Bind(R.id.ly_wallet)
    LinearLayout mLyWallet;
    @Bind(R.id.ly_share)
    LinearLayout mLyShare;
    @Bind(R.id.ly_collected)
    LinearLayout mLyCollected;
    @Bind(R.id.ly_address)
    LinearLayout mLyAddress;
    @Bind(R.id.ly_service)
    LinearLayout mLyService;
    @Bind(R.id.ly_help)
    LinearLayout mLyHelp;
    @Bind(R.id.ly_setting)
    LinearLayout mLySetting;
    @Bind(R.id.ly_business)
    LinearLayout mLyBusiness;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.spring_list)
    SpringView mSpringList;
    @Bind(R.id.tv_audit_msg_red)
    TextView tvAuditMsgRed;
    @Bind(R.id.tv_wait_msg_red)
    TextView tvWaitMsgRed;
    @Bind(R.id.tv_wait_upload_msg_red)
    TextView tvWaitUploadMsgRed;
    @Bind(R.id.tv_fail_msg_red)
    TextView tvFailMsgRed;
    @Bind(R.id.scroll)
    ScrollView mScrollView;
    @Bind(R.id.rl_title)
    RelativeLayout mRlTitle;
    @Bind(R.id.tv_msg_red1)
    TextView mTvMsgRed1;



    private UserData mUserData;

    CallbackManager callbackManager;
    ShareDialog shareDialog;
    private String mUrl;

    private UserPresenter mPresenter;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void initView() {
        super.initView();
        EventBus.getDefault().register(this);
        updateInfo();
        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);

        shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {

            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(getContext()));
        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                initData();
            }

            @Override
            public void onLoadmore() {

            }
        });

        mScrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY==0){
                    mRlTitle.setVisibility(View.GONE);
                }else {
                    mRlTitle.setVisibility(View.VISIBLE);
                }

            }
        });
    }

    @Subscribe
    public void setMsg(EventMsg eventMsg) {

        if (eventMsg.getNum() > 0) {
            mTvMsgRed.setVisibility(View.VISIBLE);
            mTvMsgRed.setText(String.valueOf(eventMsg.getNum()));

            mTvMsgRed1.setVisibility(View.VISIBLE);
            mTvMsgRed1.setText(String.valueOf(eventMsg.getNum()));

        } else {
            mTvMsgRed.setVisibility(View.GONE);
            mTvMsgRed.setText(String.valueOf(eventMsg.getNum()));

            mTvMsgRed1.setVisibility(View.GONE);
            mTvMsgRed1.setText(String.valueOf(eventMsg.getNum()));
        }

    }

    @Subscribe
    public void UserInfoUpdate(EventUserInfo eventUserInfo) {

        updateInfo();
    }

    private void updateInfo() {
        if (mTvEmail != null) {

            if (TextUtils.isEmpty(Hawk.get(AppConfig.Token, ""))) {
                mTvEmail.setText("");
                mTvUserName.setText("");
                ImageLoadUtils.loadImageCenterCrop(mContext, mIvUserPic, "", R.mipmap.user_defult_pic);
            } else {
                mUserData = App.getInstance().getUserDate();
                mTvEmail.setText(mUserData.getUsername());
                mTvUserName.setText(mUserData.getNickname());
                ImageLoadUtils.loadImageCenterCrop(mContext, mIvUserPic, mUserData.getHead_img(), R.mipmap.user_defult_pic);
            }

        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_mine;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new UserPresenter(this);
    }


    @OnClick({R.id.iv_user_pic, R.id.ly_audit, R.id.ly_wait_et, R.id.ly_wait_upload, R.id.ly_fail, R.id.ly_wallet, R.id.ly_share, R.id.ly_collected,
            R.id.ly_address, R.id.ly_service, R.id.ly_help, R.id.ly_setting, R.id.ly_business, R.id.ly_left, R.id.iv_right,R.id.ly_left1,R.id.iv_right1})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_user_pic:
                jumpActivity(null, UserInfoActivity.class);
                break;
            case R.id.ly_audit:
                mUrl = AppNetConfig.WEB_URL + "order?status=0&";
                jumAct("Order");
                break;
            case R.id.ly_wait_et:
                mUrl = AppNetConfig.WEB_URL + "order?status=1&";
                jumAct("Order");
                break;
            case R.id.ly_wait_upload:
                mUrl = AppNetConfig.WEB_URL + "order?status=3&";
                jumAct("Order");
                break;
            case R.id.ly_fail:
                mUrl = AppNetConfig.WEB_URL + "order?status=8&";
                jumAct("Order");
                break;
            case R.id.ly_wallet:
                mUrl = AppNetConfig.WEB_URL + "wallet?";
                jumAct("My Wallet");
                break;
            case R.id.ly_share:
                EventBus.getDefault().post(new EventIntentFree(3));
//                if (ShareDialog.canShow(ShareLinkContent.class)) {
//                    ShareLinkContent linkContent = new ShareLinkContent.Builder()
//                            .setContentUrl(Uri.parse(Hawk.get(AppConfig.Share_URL, "")))
//                            .build();
//                    shareDialog.show(linkContent);
//                }
                break;
            case R.id.ly_collected:
                mUrl = AppNetConfig.WEB_URL + "collection?";
                jumAct("My Collected");
                break;
            case R.id.ly_address:
                mUrl = AppNetConfig.WEB_URL + "addresslist?";
                jumAct("Shipping address");
                break;
            case R.id.ly_service:
                mUrl = AppNetConfig.WEB_URL + "cs?";
                jumAct("Customer Service");
                break;
            case R.id.ly_help:
                mUrl = AppNetConfig.WEB_URL + "help?";
                jumAct("Help Center");
                break;
            case R.id.ly_setting:
                jumpActivity(null, SettingActivity.class);
                break;
            case R.id.ly_business:
                mUrl = AppNetConfig.WEB_URL + "merchant?";
                jumAct("Seller center");
                break;
            case R.id.ly_left:
            case R.id.ly_left1:
                EventBus.getDefault().post(new EventIntentFree(0));
                break;
            case R.id.iv_right:
            case R.id.iv_right1:
                jumpActivity(null, MsgActivity.class);
                break;
        }
    }

    public void jumAct(String title) {

        Bundle bundle = new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
        bundle.putString(AppConfig.WEB_TITLE, title);
        jumpActivity(bundle, WebActivity.class);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void bindDataToView(UserOrderStateBean netBean) {
        if (netBean.getError_code() == 0) {
            if (netBean.getData().getAudit() > 0) {
                tvAuditMsgRed.setText(String.valueOf(netBean.getData().getAudit()));
                tvAuditMsgRed.setVisibility(View.VISIBLE);
            } else {
                tvAuditMsgRed.setVisibility(View.GONE);
            }

            if (netBean.getData().getWrite() > 0) {
                tvWaitMsgRed.setText(String.valueOf(netBean.getData().getWrite()));
                tvWaitMsgRed.setVisibility(View.VISIBLE);
            } else {
                tvWaitMsgRed.setVisibility(View.GONE);
            }

            if (netBean.getData().getImage() > 0) {
                tvWaitUploadMsgRed.setText(String.valueOf(netBean.getData().getImage()));
                tvWaitUploadMsgRed.setVisibility(View.VISIBLE);
            } else {
                tvWaitUploadMsgRed.setVisibility(View.GONE);
            }

            if (netBean.getData().getFail() > 0) {
                tvFailMsgRed.setText(String.valueOf(netBean.getData().getFail()));
                tvFailMsgRed.setVisibility(View.VISIBLE);
            } else {
                tvFailMsgRed.setVisibility(View.GONE);
            }
        }

        closeRefreshView();
    }
    public void closeRefreshView() {
        mSpringList.setEnable(true);
        mSpringList.onFinishFreshAndLoad();
    }
}
