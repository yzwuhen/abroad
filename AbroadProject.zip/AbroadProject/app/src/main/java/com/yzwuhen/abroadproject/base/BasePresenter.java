package com.yzwuhen.abroadproject.base;


/**
 * Created by yz_wuhen on 2017/8/25.
 */

public interface BasePresenter <T>{


    void initRefreshData();

    void loadMoreNetData();

    void showErrorStateView();

    void showSuccessView();

    void bindDataToView(T t);

    void bindMoreDataToView(T t);

    void showLoadingView();

    void destoryView();
}
