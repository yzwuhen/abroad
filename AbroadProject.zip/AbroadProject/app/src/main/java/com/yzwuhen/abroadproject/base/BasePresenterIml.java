package com.yzwuhen.abroadproject.base;


import com.yz.base.BaseView;

/**
 * Created by zhangguorong on 2017/6/13.
 */

public abstract class BasePresenterIml<T> implements BasePresenter<T> {
    protected BaseView baseView;

    public BasePresenterIml(BaseView baseView) {
        this.baseView = baseView;

    }
    @Override
    public void initRefreshData() {
        requestNetData();
    }

    protected abstract void requestNetData();

    @Override
    public void bindDataToView(T t) {
        if (baseView!=null)
        baseView.bindDataToView(t);
    }

    @Override
    public void bindMoreDataToView(T t) {
        if (baseView!=null)
        baseView.bindMoreDataToView(t);
    }

    @Override
    public void loadMoreNetData() {
        loadChildMoreNetData();
    }

    protected abstract void loadChildMoreNetData();

    @Override
    public void showLoadingView() {
        if (baseView!=null)
        baseView.showLoadingView();
    }

    @Override
    public void showSuccessView() {
        if (baseView!=null)
        baseView.showSuccessView();
    }


    @Override
    public void destoryView() {
        if (baseView!=null)
        baseView = null;
    }



}
