package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.data.RecommendData;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;
import com.yzwuhen.abroadproject.utils.SignUtils;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class CommodityAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private List<RecommendData> mList;
    private VhOnItemClickListener mItemClickListener;

    public CommodityAdapter(Context context, List<RecommendData> list, VhOnItemClickListener vhOnItemClickListener) {

        this.mContext = context;
        this.mList = list;
        this.mItemClickListener = vhOnItemClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(parent.getContext(), R.layout.item_goods_h, null);
        return new CommodityHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        CommodityHolder commodityHolder = (CommodityHolder) holder;
        String ss ="$"+mList.get(position).getPrice();

        commodityHolder.mTvPrice.setText(ss);
        commodityHolder.mTvPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG );
       commodityHolder.mTvCostPrice.setText(mList.get(position).getStock());

        String test ="Return of deposit $"+ mList.get(position).getRebate();
        commodityHolder.mTvReturnPrice.setText(SignUtils.bigText(test));

         commodityHolder.mTvGoodsName.setText(mList.get(position).getTitle());
        ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),commodityHolder.mIvPic,mList.get(position).getPreview(),R.mipmap.news_goods_defult);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class CommodityHolder extends RecyclerView.ViewHolder {

        @Bind(R.id.iv_pic)
        CusImageView mIvPic;
        @Bind(R.id.tv_goods_name)
        TextView mTvGoodsName;
        @Bind(R.id.tv_price)
        TextView mTvPrice;
        @Bind(R.id.tv_cost_price)
        TextView mTvCostPrice;
        @Bind(R.id.tv_return_price)
        TextView mTvReturnPrice;

        public CommodityHolder(View itemView) {
            super(itemView);

            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(v, getAdapterPosition());

                }
            });
        }
    }


}
