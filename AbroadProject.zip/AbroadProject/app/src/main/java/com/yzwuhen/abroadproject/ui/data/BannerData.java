package com.yzwuhen.abroadproject.ui.data;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class BannerData {
    /**
     * promote_id : 1
     * title : 百度友情链接
     * img_path :
     * url : /common/promote/v0/1
     */

    private int promote_id;
    private String title;
    private String img_path;
    private String url;

    public int getPromote_id() {
        return promote_id;
    }

    public void setPromote_id(int promote_id) {
        this.promote_id = promote_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg_path() {
        return img_path;
    }

    public void setImg_path(String img_path) {
        this.img_path = img_path;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
