package com.yzwuhen.abroadproject.ui.activity;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.SearchHotBean;
import com.yzwuhen.abroadproject.ui.adapter.HotSearchAdapter;
import com.yzwuhen.abroadproject.ui.adapter.SearchHistoryAdapter;
import com.yzwuhen.abroadproject.ui.data.HotKeyData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.SearchPresenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class SearchActivity extends BaseActivity<SearchHotBean> implements VhOnItemClickListener{
    @Bind(R.id.et_search)
    EditText mEtSearch;
    @Bind(R.id.ly_search)
    LinearLayout mLySearch;
    @Bind(R.id.tv_cancel)
    TextView mTvCancel;
    @Bind(R.id.ly_history)
    LinearLayout mLyHistory;
    @Bind(R.id.rv_history)
    RecyclerView mRvHistory;
    @Bind(R.id.rv_hot)
    RecyclerView mRvHot;
    @Bind(R.id.iv_close)
    ImageView mIvClose;

    private SearchHistoryAdapter mAdapter;
    private HotSearchAdapter mHotSearchAdapter;

    private List<String> mHistoryList;
    private List<HotKeyData> mHotList;

    private String mHistorys;// 这个是历史记录字符串用，隔开

    private SearchPresenter mPresenter;

    private String searchText;//搜索框的字符

    @Override
    protected void initView() {
        super.initView();


        mHistoryList = new ArrayList<>();
        mHotList =new ArrayList<>();

        mHistorys =Hawk.get(AppConfig.HISTORY,"");
        if (!TextUtils.isEmpty(mHistorys)){
            mHistoryList.addAll(Arrays.asList(mHistorys.split(",")));
        }



        mAdapter = new SearchHistoryAdapter(this,mHistoryList,this);
        mHotSearchAdapter =new HotSearchAdapter(this,mHotList,this);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,3);

        mRvHistory.setLayoutManager(gridLayoutManager);
        mRvHot.setLayoutManager(new GridLayoutManager(this,3));

        mRvHot.setAdapter(mHotSearchAdapter);
        mRvHistory.setAdapter(mAdapter);
        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    getText();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mEtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId==3){
                    recordStr();
                }


                return false;
            }
        });

    }

    private void getText() {
        searchText =mEtSearch.getText().toString().trim();
        if (TextUtils.isEmpty(searchText)){
            mIvClose.setVisibility(View.GONE);
        }else {
            mIvClose.setVisibility(View.VISIBLE);
        }

    }

    private void recordStr( ) {
        if (mHistoryList.size()==9){
            mHistoryList.remove(0);
        }
        mHistoryList.add(searchText);
        mHistorys ="";
        StringBuilder stringBuilder = new StringBuilder();
        for (int i=0;i<mHistoryList.size();i++){
            stringBuilder.append(mHistoryList.get(i));
            if (i!=mHistoryList.size()){
                stringBuilder.append(",");
            }
        }
        mHistorys =stringBuilder.toString().trim();
       Hawk.put(AppConfig.HISTORY,mHistorys);

        mAdapter.notifyItemChanged(mHistoryList.size());

        Bundle bundle = new Bundle();
            bundle.putString("key",searchText);
        jumpActivity(bundle,SearchRresultActivity.class);
    }

    @Override
    public void bindDataToView(SearchHotBean searchHotBean) {

        if (searchHotBean.getError_code()==0){
            mHotList.addAll(searchHotBean.getData().getList());
            mHotSearchAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_search;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter =new SearchPresenter(this);
    }


    @OnClick({R.id.tv_cancel, R.id.ly_history,R.id.iv_close})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_cancel:
                finish();
                break;
            case R.id.ly_history:
                mHistoryList.clear();
                Hawk.delete(AppConfig.HISTORY);
                mAdapter.notifyDataSetChanged();
                break;
            case R.id.iv_close:
                mEtSearch.setText("");
                break;
        }
    }

    @Override
    public void onItemOnclick(View v, int position) {
        Bundle bundle = new Bundle();
        if (v.getId()==R.id.tv_hottest){
            bundle.putString("key",mHotList.get(position).getKeyword());
        }else {
            bundle.putString("key",mHistoryList.get(position));
        }
        jumpActivity(bundle,SearchRresultActivity.class);
    }
}
