package com.yzwuhen.abroadproject;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventFree;
import com.yzwuhen.abroadproject.bean.eventBus.EventIntentFree;
import com.yzwuhen.abroadproject.bean.eventBus.EventMsg;
import com.yzwuhen.abroadproject.bean.eventBus.EventUserInfo;
import com.yzwuhen.abroadproject.ui.activity.LoginAndReister;
import com.yzwuhen.abroadproject.ui.activity.MsgActivity;
import com.yzwuhen.abroadproject.ui.activity.SettingActivity;
import com.yzwuhen.abroadproject.ui.activity.UserInfoActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.data.UserData;
import com.yzwuhen.abroadproject.ui.fragment.FreeFragment;
import com.yzwuhen.abroadproject.ui.fragment.HomeFragment;
import com.yzwuhen.abroadproject.ui.fragment.ShareFragment;
import com.yzwuhen.abroadproject.ui.fragment.UserFragment;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.MainPresenter;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

public class MainActivity extends BaseActivity<NetBean> {


    @Bind(R.id.main_frame)
    FrameLayout mMainFrame;
    @Bind(R.id.iv_user_pic)
    CusImageView mIvUserPic;
    @Bind(R.id.iv_home)
    ImageView mIvHome;
    @Bind(R.id.tv_home)
    TextView mTvHome;
    @Bind(R.id.ly_home)
    LinearLayout mLyHome;
    @Bind(R.id.iv_free)
    ImageView mIvFree;
    @Bind(R.id.tv_free)
    TextView mTvFree;
    @Bind(R.id.ly_free)
    LinearLayout mLyFree;
    @Bind(R.id.iv_share)
    ImageView mIvShare;
    @Bind(R.id.tv_share)
    TextView mTvShare;
    @Bind(R.id.ly_share)
    LinearLayout mLyShare;
    @Bind(R.id.iv_user)
    ImageView mIvUser;
    @Bind(R.id.tv_user)
    TextView mTvUser;
    @Bind(R.id.ly_user)
    LinearLayout mLyUser;
    @Bind(R.id.iv_order)
    ImageView mIvOrder;
    @Bind(R.id.tv_order)
    TextView mTvOrder;
    @Bind(R.id.ly_order)
    LinearLayout mLyOrder;
    @Bind(R.id.iv_wallet)
    ImageView mIvWallet;
    @Bind(R.id.tv_wallet)
    TextView mTvWallet;
    @Bind(R.id.ly_wallet)
    LinearLayout mLyWallet;
    @Bind(R.id.iv_collect)
    ImageView mIvCollect;
    @Bind(R.id.tv_collect)
    TextView mTvCollect;
    @Bind(R.id.ly_collect)
    LinearLayout mLyCollect;
    @Bind(R.id.iv_help)
    ImageView mIvHelp;
    @Bind(R.id.tv_help)
    TextView mTvHelp;
    @Bind(R.id.ly_help)
    LinearLayout mLyHelp;
    @Bind(R.id.iv_service)
    ImageView mIvService;
    @Bind(R.id.tv_service)
    TextView mTvService;
    @Bind(R.id.ly_service)
    LinearLayout mLyService;
    @Bind(R.id.iv_setting)
    ImageView mIvSetting;
    @Bind(R.id.tv_setting)
    TextView mTvSetting;
    @Bind(R.id.ly_setting)
    LinearLayout mLySetting;
    @Bind(R.id.tv_login_out)
    TextView mTvLoginOut;
    @Bind(R.id.main_dl)
    DrawerLayout mMainDl;
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.tv_nick)
    TextView mTvNick;
    @Bind(R.id.tv_email)
    TextView mTvEmail;
    @Bind(R.id.tv_login_in)
    TextView mTvLoginIn;
    @Bind(R.id.iv_logo)
    ImageView mIvLogo;


    private FragmentManager mManager;

    private HomeFragment mHomeFragment;
    private FreeFragment mFreeFragment;
    private ShareFragment mShareFragment;
    private UserFragment mUserFragment;

    private List<TextView> mTextViews;
    private List<ImageView> mImageViews;
    private List<LinearLayout> mLinearLayouts;

    private MainPresenter mPresenter;
    private UserData mUserData;

    private String mUrl;

    private Fragment mFragment;

    @Override
    protected void onResume() {
        super.onResume();
        showSildState();

    }

    public void showSildState(){

        EventBus.getDefault().post(new EventUserInfo());
        if (Hawk.get(AppConfig.Token)!=null){
            mTvLoginIn.setVisibility(View.GONE);
            mTvLoginOut.setVisibility(View.VISIBLE);
            mTvNick.setVisibility(View.VISIBLE);
            mTvEmail.setVisibility(View.VISIBLE);
            mUserData = App.getInstance().getUserDate();

            mTvEmail.setText(mUserData.getUsername());
            mTvNick.setText(mUserData.getNickname());
            ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),mIvUserPic,mUserData.getHead_img(),R.mipmap.user_defult_pic);

        }else {
            ImageLoadUtils.loadImageCenterCrop(App.getInstance().getApplicationContext(),mIvUserPic,"",R.mipmap.user_defult_pic);
            mTvLoginIn.setVisibility(View.VISIBLE);
            mTvLoginOut.setVisibility(View.GONE);
            mTvNick.setVisibility(View.GONE);
            mTvEmail.setVisibility(View.GONE);
        }
    }
    @Override
    protected void initView() {
        super.initView();

        mManager = getSupportFragmentManager();

        mHomeFragment = new HomeFragment();
        mFreeFragment = new FreeFragment();
        mShareFragment = new ShareFragment();
        mUserFragment = new UserFragment();

        mTextViews = new ArrayList<>();
        mImageViews = new ArrayList<>();
        mLinearLayouts = new ArrayList<>();

        mTextViews.add(mTvHome);
        mTextViews.add(mTvFree);
        mTextViews.add(mTvShare);
        mTextViews.add(mTvUser);

        mImageViews.add(mIvHome);
        mImageViews.add(mIvFree);
        mImageViews.add(mIvShare);
        mImageViews.add(mIvUser);

        mLinearLayouts.add(mLyHome);
        mLinearLayouts.add(mLyFree);
        mLinearLayouts.add(mLyShare);
        mLinearLayouts.add(mLyUser);

        clickHome();
        selectItem(0);

         EventBus.getDefault().register(this);


    }
    @Subscribe
    public void clickMore(EventIntentFree eventIntentFree){

        if (eventIntentFree.getType()==0){

            mMainDl.openDrawer(Gravity.LEFT);

        }
        else if (eventIntentFree.getType()==3){
            clickShare();
            selectItem(2);
        }

        else {
            clockFree();
            selectItem(1);
            EventBus.getDefault().post(new EventFree(eventIntentFree.getType()));
        }

    }
    @Subscribe
    public void setMsg(EventMsg eventMsg){

        if (eventMsg.getNum()>0){
            mTvMsgRed.setVisibility(View.VISIBLE);
            mTvMsgRed.setText(String.valueOf(eventMsg.getNum()));
        }else {
            mTvMsgRed.setVisibility(View.GONE);
            mTvMsgRed.setText(String.valueOf(eventMsg.getNum()));
        }

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new MainPresenter(this);
    }

    @Override
    public void bindDataToView(NetBean netBean) {
        showSildState();
    }

    private void clickHome() {
        FragmentTransaction transaction = mManager.beginTransaction();
        if (mHomeFragment == null) {
            mHomeFragment = new HomeFragment();
            transaction.add(R.id.main_frame, mHomeFragment);
        } else {
            showFragment(transaction, mHomeFragment);
        }

        this.mFragment =mHomeFragment;
        hideOtherFragment(transaction, mFreeFragment, mShareFragment, mUserFragment);
        transaction.commitAllowingStateLoss();
    }

    private void clockFree() {
        FragmentTransaction transaction = mManager.beginTransaction();
        if (mFreeFragment == null) {
            mFreeFragment = new FreeFragment();
            transaction.add(R.id.main_frame, mFreeFragment);
        } else {
            showFragment(transaction, mFreeFragment);
        }
        this.mFragment =mFreeFragment;
        hideOtherFragment(transaction, mHomeFragment, mShareFragment, mUserFragment);
        transaction.commitAllowingStateLoss();
    }

    private void clickShare() {
        FragmentTransaction transaction = mManager.beginTransaction();
        if (mShareFragment == null) {
            mShareFragment = new ShareFragment();
            transaction.add(R.id.main_frame, mShareFragment);
        } else {
            showFragment(transaction, mShareFragment);
        }
        this.mFragment =mShareFragment;
        hideOtherFragment(transaction, mFreeFragment, mHomeFragment, mUserFragment);
        transaction.commitAllowingStateLoss();
    }

    private void clickUser() {
        FragmentTransaction transaction = mManager.beginTransaction();
        if (mUserFragment == null) {
            mUserFragment = new UserFragment();
            transaction.add(R.id.main_frame, mUserFragment);
        } else {
            showFragment(transaction, mUserFragment);
        }
        this.mFragment =mUserFragment;
        hideOtherFragment(transaction, mFreeFragment, mShareFragment, mHomeFragment);
        transaction.commitAllowingStateLoss();
    }

    /**
     * 隐藏其他Fragment
     *
     * @param transaction
     * @param fragment1
     * @param fragment2
     * @param fragment3
     */
    private void hideOtherFragment(FragmentTransaction transaction, BaseFragment fragment1, BaseFragment fragment2, BaseFragment fragment3) {
        hideFragment(transaction, fragment1);
        hideFragment(transaction, fragment2);
        hideFragment(transaction, fragment3);
    }

    /*
    * 隐藏一个Fragment
    */
    protected void hideFragment(FragmentTransaction transaction, Fragment fragment) {
        if (fragment != null && fragment.isAdded()) {
            transaction.hide(fragment);
        }
    }

    /*
     * 显示一个Fragment
     */
    protected void showFragment(FragmentTransaction transaction, Fragment fragment) {
        if (fragment == null) return;
        if (fragment.isAdded()) {
            transaction.show(fragment);
        } else {
            transaction.add(R.id.main_frame, fragment);
        }
    }

    private void selectItem(int index) {

        mMainDl.closeDrawers();

        if (index == 3) {
//            mIvLeft.setImageResource(R.mipmap.dl_menu_nor);
//            mIvRight.setImageResource(R.mipmap.msg_icon_nor);
//            mLyTitle.setBackgroundColor(getResources().getColor(R.color.blue_drawer));
            mLyTitle.setVisibility(View.GONE);
            modifyStateColor(R.color.blue_drawer);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_VISIBLE);
        } else {
            mLyTitle.setVisibility(View.VISIBLE);
            mIvLeft.setImageResource(R.mipmap.dl_menu);
            mIvRight.setImageResource(R.mipmap.msg_icon);
            mLyTitle.setBackgroundColor(getResources().getColor(R.color.white));
            modifyStateColor(R.color.white);
            //修改状态栏 图标字体颜色
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        for (int i = 0; i < mTextViews.size(); i++) {
            if (i == index) {
                mTextViews.get(i).setSelected(true);
                mImageViews.get(i).setSelected(true);
                mLinearLayouts.get(i).setSelected(true);
            } else {
                mTextViews.get(i).setSelected(false);
                mImageViews.get(i).setSelected(false);
                mLinearLayouts.get(i).setSelected(false);
            }
        }
        if (index==2){
            mTvTitle.setText("Share");
            mTvTitle.setVisibility(View.VISIBLE);
            mIvLogo.setVisibility(View.GONE);
        }else {
            mTvTitle.setVisibility(View.GONE);
            mIvLogo.setVisibility(View.VISIBLE);
        }
    }



    @OnClick({R.id.iv_user_pic, R.id.ly_home,R.id.tv_login_in, R.id.ly_free, R.id.ly_share, R.id.ly_user, R.id.ly_order, R.id.ly_wallet, R.id.ly_collect, R.id.ly_help, R.id.ly_service, R.id.ly_setting, R.id.tv_login_out, R.id.ly_left, R.id.ly_right})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_user_pic:
                if (!TextUtils.isEmpty(Hawk.get(AppConfig.Token,"")))
                {
                    mMainDl.closeDrawers();
                    jumpActivity(null, UserInfoActivity.class);
                }else {
                  jumpActivity(null, LoginAndReister.class);
                }
                break;
            case R.id.ly_home:
                clickHome();
                selectItem(0);
                break;
            case R.id.ly_free:
                clockFree();
                selectItem(1);
                break;
            case R.id.ly_share:
                if (!TextUtils.isEmpty(Hawk.get(AppConfig.Token,"")))
                {
                    clickShare();
                    selectItem(2);
                }else {
                    jumpActivity(null, LoginAndReister.class);
                }
                break;
            case R.id.ly_user:
                if (!TextUtils.isEmpty(Hawk.get(AppConfig.Token,"")))
                {
                    clickUser();
                    selectItem(3);
                }else {
                    jumpActivity(null, LoginAndReister.class);
                }
                break;
            case R.id.tv_login_in:
                mMainDl.closeDrawers();
                jumpActivity(null, LoginAndReister.class);
                break;
            case R.id.ly_order:
                mUrl = AppNetConfig.WEB_URL +"order?";
                junWebAct("Order");
                break;
            case R.id.ly_wallet:
                mUrl = AppNetConfig.WEB_URL +"wallet?";
                junWebAct("My Wallet");
                break;
            case R.id.ly_collect:
                mUrl = AppNetConfig.WEB_URL+"collection?";
                junWebAct("My Collected");
                break;
            case R.id.ly_help:
                mUrl = AppNetConfig.WEB_URL +"help?";
                junWebAct("Help Center");
                break;
            case R.id.ly_service:
                mUrl = AppNetConfig.WEB_URL+"cs?";
                junWebAct("Customer Service");
                break;
            case R.id.ly_setting:
                if (!TextUtils.isEmpty(Hawk.get(AppConfig.Token,"")))
                {
                    jumpActivity(null, SettingActivity.class);
                }else {
                    jumpActivity(null, LoginAndReister.class);
                }
                break;
            case R.id.tv_login_out:
                if (mFragment instanceof  UserFragment||mFragment instanceof ShareFragment){
                    clickHome();
                    selectItem(0);
                }
                mMainDl.closeDrawers();
                mPresenter.loginOut();
                break;
            case R.id.ly_left:
                mMainDl.openDrawer(Gravity.LEFT);
                break;
            case R.id.ly_right:
                jumpActivity(null, MsgActivity.class);
                break;
        }
    }

    public void junWebAct(String title){
        mMainDl.closeDrawers();
        if (!TextUtils.isEmpty(Hawk.get(AppConfig.Token,"")))
        {

            Bundle bundle =new Bundle();
            bundle.putString(AppConfig.WEB_LOAD_URL,mUrl);
            bundle.putString(AppConfig.WEB_TITLE,title);
            jumpActivity(bundle, WebActivity.class);
        }else {
            jumpActivity(null, LoginAndReister.class);

        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
