package com.yzwuhen.abroadproject;

import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.support.multidex.MultiDex;
import android.text.TextUtils;

import com.orhanobut.hawk.Hawk;
import com.orhanobut.hawk.NoEncryption;
import com.yz.NetApplication;
import com.yzwuhen.abroadproject.ui.data.UserData;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;


/**
 * Created by yz_wuhen on 2017/8/28.
 */

public class App extends NetApplication {


    private static App instance;


    private UserData mUserData;


    public static App getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;


        Hawk.init(this)
                .setEncryption(new NoEncryption())
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }

    }



    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
    public UserData getUserDate(){

        if (mUserData == null|| TextUtils.isEmpty(mUserData.getUsername())){
            mUserData = Hawk.get(AppConfig.USER_INFO,null);
        }

        //避免出现空指针
        if (mUserData==null){
            mUserData = new UserData();
        }

        return mUserData;
    }
    //更新用户资料
    public void setUserData(UserData userData){
        this.mUserData=userData;
        if (mUserData ==null){
            mUserData =new UserData();
        }
    }

}
