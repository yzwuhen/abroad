package com.yzwuhen.abroadproject.ui.data;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class HotKeyData {
    /**
     * keyword : banner
     */

    private String keyword;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}
