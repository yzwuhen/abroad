package com.yzwuhen.abroadproject.ui.data;

/**
 * Created by yz_wuhen on 2019/10/9/009.
 */

public class VisitorData {
    /**
     * visitor_id : nK25VnAUCT/HIJxq1c/PDbuZgHU/eXk/
     */

    private String visitor_id;

    public String getVisitor_id() {
        return visitor_id;
    }

    public void setVisitor_id(String visitor_id) {
        this.visitor_id = visitor_id;
    }
}
