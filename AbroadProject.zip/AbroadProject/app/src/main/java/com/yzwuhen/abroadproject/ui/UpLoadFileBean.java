package com.yzwuhen.abroadproject.ui;

import com.yzwuhen.abroadproject.bean.NetBean;

/**
 * Created by yz_wuhen on 2019/10/13/013.
 */

public class UpLoadFileBean extends NetBean {

    /**
     * data : {"file_id":14,"file_path":"http://47.103.28.192/assets/upload/client/201910/38872019101311113720.jpg"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * file_id : 14
         * file_path : http://47.103.28.192/assets/upload/client/201910/38872019101311113720.jpg
         */

        private int file_id;
        private String file_path;

        public int getFile_id() {
            return file_id;
        }

        public void setFile_id(int file_id) {
            this.file_id = file_id;
        }

        public String getFile_path() {
            return file_path;
        }

        public void setFile_path(String file_path) {
            this.file_path = file_path;
        }
    }
}
