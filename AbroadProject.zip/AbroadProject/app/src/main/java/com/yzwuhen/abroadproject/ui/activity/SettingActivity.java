package com.yzwuhen.abroadproject.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.SettingPresenter;
import com.yzwuhen.abroadproject.utils.MyDataCleanManager;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/6/006.
 */

public class SettingActivity extends BaseActivity<NetBean> {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.rl_modidy_pwd)
    RelativeLayout mRlModidyPwd;
    @Bind(R.id.rl_modify_pay_pwd)
    RelativeLayout mRlModifyPayPwd;
    @Bind(R.id.rl_agreement)
    RelativeLayout mRlAgreement;
    @Bind(R.id.rl_privacy)
    RelativeLayout mRlPrivacy;
    @Bind(R.id.rl_about_us)
    RelativeLayout mRlAboutUs;
    @Bind(R.id.tv_cache)
    TextView mTvCache;
    @Bind(R.id.rl_cache)
    RelativeLayout mRlCache;
    @Bind(R.id.tv_login_out)
    TextView mTvLoginOut;
    @Bind(R.id.iv_logo)
    ImageView mIvLogo;
    private String  dataSize;

    private String mUrl;
    private String mWebTitle;
    private SettingPresenter mPresenter;
    @Override
    protected void initView() {
        super.initView();
        mIvLeft.setImageResource(R.mipmap.sys_back);
        mIvLogo.setVisibility(View.GONE);
        mTvTitle.setVisibility(View.VISIBLE);
        mTvTitle.setText("System settings");

        mWebTitle ="System settings";

        mLyRight.setVisibility(View.INVISIBLE);
        try {
            dataSize = MyDataCleanManager.getTotalCacheSize(getApplicationContext());
            mTvCache.setText(dataSize);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void bindDataToView(NetBean netBean) {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_setting;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter =new SettingPresenter(this);
    }



    @OnClick({R.id.ly_left, R.id.rl_modidy_pwd, R.id.rl_modify_pay_pwd, R.id.rl_agreement, R.id.rl_privacy, R.id.rl_about_us, R.id.rl_cache, R.id.tv_login_out})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
                finish();
                break;
            case R.id.rl_modidy_pwd:
                mUrl = AppNetConfig.WEB_URL+"modifypass?";
                jumWeb();
                break;
            case R.id.rl_modify_pay_pwd:
                mUrl = AppNetConfig.WEB_URL+"modifypay?";
                jumWeb();
                break;
            case R.id.rl_agreement:
                mUrl = AppNetConfig.WEB_URL+"agreement?";
                jumWeb();
                break;
            case R.id.rl_privacy:
                break;
            case R.id.rl_about_us:
                break;
            case R.id.rl_cache:
                MyDataCleanManager.clearAllCache(this);
                mTvCache.setText("0B");
                break;
            case R.id.tv_login_out:
                mPresenter.loginOut();
                break;
        }
    }

    public void jumWeb(){
        Bundle bundle = new Bundle();
        bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
        bundle.putString(AppConfig.WEB_TITLE,mWebTitle);
        jumpActivity(bundle, WebActivity.class);
    }
}
