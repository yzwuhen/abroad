package com.yzwuhen.abroadproject.ui.presenter;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.SearchHotBean;
import com.yzwuhen.abroadproject.bean.requestBean.BaseRequestBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class SearchPresenter extends BasePresenterIml<NetBean> {

    BaseRequestBean mBaseRequestBean = new BaseRequestBean();
    public SearchPresenter(BaseView baseView) {
        super(baseView);
    }

    @Override
    public void showErrorStateView() {

    }

    @Override
    protected void requestNetData() {

        getHotList();
    }

    private void getHotList() {
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));


        mBaseRequestBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mBaseRequestBean.setSign(SignUtils.sign(map));
        mBaseRequestBean.setTimestamp(map.get("timestamp"));
        mBaseRequestBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().getHotList(mBaseRequestBean,new NetSubscriber<SearchHotBean>(new SubscriberListener<SearchHotBean>(baseView) {
            @Override
            public void onNext(SearchHotBean searchHotBean) {
                        bindDataToView(searchHotBean);
                if (searchHotBean.getError_code()!=0){
                    ToastUtils.showMsg(searchHotBean.getError_msg());
                }
            }
        }));
    }

    @Override
    protected void loadChildMoreNetData() {

    }
}
