package com.yzwuhen.abroadproject.ui.presenter;

import android.util.Log;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.bean.FreeTabBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReFreeGoodsBean;
import com.yzwuhen.abroadproject.ui.fragment.FreeFragment;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.ui.netiml.NetSub;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class FreePresenter extends BasePresenterIml<NetBean> {
    ReFreeGoodsBean mFreeGoodsBean = new ReFreeGoodsBean();
    private boolean isGetTab;
    private int pages;
    public FreePresenter(BaseView baseView, int page, String orderBy) {
        super(baseView);
        mFreeGoodsBean.setPage(page);
        mFreeGoodsBean.setOrder_by(orderBy);
    }

    @Override
    public void showErrorStateView() {

    }

    @Override
    protected void requestNetData() {
        if (!isGetTab){
            getFreeTab();
        }else {
            pages=1;
           getUpdatePage();
        }

    }



    public void getFreeTab(){
        isGetTab =true;
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));


        mFreeGoodsBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mFreeGoodsBean.setSign(SignUtils.sign(map));
        mFreeGoodsBean.setTimestamp(map.get("timestamp"));
        mFreeGoodsBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().getFreeTab(mFreeGoodsBean,new NetSub<FreeTabBean>(new SubscriberListener<FreeTabBean>(baseView) {
            @Override
            public void onNext(FreeTabBean freeTabBean) {

                            bindDataToView(freeTabBean);
                            if (freeTabBean.getData().getList().size()>0){
                                getFreeGoods(freeTabBean.getData().getList().get(0).getType_id(),mFreeGoodsBean.getPage(),mFreeGoodsBean.getOrder_by());
                            }

                      if (freeTabBean.getError_code()!=0){
                            ToastUtils.showMsg(freeTabBean.getError_msg());
                        }
            }
        }));
    }
    public void getFreeGoods(int type_id, int page, String orderBy){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        map.put("type_id",String.valueOf(type_id));
        map.put("search","");
        map.put("order_by",orderBy);
        map.put("page",String.valueOf(page));
        map.put("limit","20");

        mFreeGoodsBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mFreeGoodsBean.setPage(page);
        mFreeGoodsBean.setOrder_by(orderBy);
        mFreeGoodsBean.setType_id(type_id);
        mFreeGoodsBean.setSign(SignUtils.sign(map));
        mFreeGoodsBean.setTimestamp(map.get("timestamp"));
        mFreeGoodsBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        HttpApiIml.getInstance().create().getFreeGoods(mFreeGoodsBean,new NetSub<FreeGoodsBean>(new SubscriberListener<FreeGoodsBean>(baseView) {
            @Override
            public void onNext(FreeGoodsBean netBean) {

                ((FreeFragment)baseView).upData(netBean,mFreeGoodsBean.getPage());

                if (netBean.getError_code()!=0){
                    ToastUtils.showMsg(netBean.getError_msg());
                }

            }
        }));
    }

    //更新orderBy 查询
    public void getUpdateCondition(String orderBy){

        pages=1;

        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        map.put("type_id",String.valueOf(mFreeGoodsBean.getType_id()));
        map.put("search","");
        map.put("order_by",orderBy);
        map.put("page",String.valueOf(pages));
        map.put("limit","20");

        mFreeGoodsBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mFreeGoodsBean.setPage(pages);
        mFreeGoodsBean.setOrder_by(orderBy);
        mFreeGoodsBean.setSign(SignUtils.sign(map));
        mFreeGoodsBean.setTimestamp(map.get("timestamp"));
        mFreeGoodsBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        HttpApiIml.getInstance().create().getFreeGoods(mFreeGoodsBean,new NetSub<FreeGoodsBean>(new SubscriberListener<FreeGoodsBean>(baseView) {
            @Override
            public void onNext(FreeGoodsBean netBean) {

                 ((FreeFragment)baseView).upData(netBean,mFreeGoodsBean.getPage());

                if (netBean.getError_code()!=0){
                    ToastUtils.showMsg(netBean.getError_msg());
                }

            }
        }));
    }
    //更新page 查询 其实就是刷新 和加载更多
    private void getUpdatePage() {
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        map.put("type_id",String.valueOf(mFreeGoodsBean.getType_id()));
        map.put("search","");
        map.put("order_by",mFreeGoodsBean.getOrder_by());
        map.put("page",String.valueOf(pages));
        map.put("limit","20");

        mFreeGoodsBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mFreeGoodsBean.setPage(pages);
        mFreeGoodsBean.setSign(SignUtils.sign(map));
        mFreeGoodsBean.setTimestamp(map.get("timestamp"));
        mFreeGoodsBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        HttpApiIml.getInstance().create().getFreeGoods(mFreeGoodsBean,new NetSub<FreeGoodsBean>(new SubscriberListener<FreeGoodsBean>(baseView) {
            @Override
            public void onNext(FreeGoodsBean netBean) {
                ((FreeFragment)baseView).upData(netBean,mFreeGoodsBean.getPage());
                if (netBean.getError_code()!=0){
                    ToastUtils.showMsg(netBean.getError_msg());
                }

            }
        }));
    }

    @Override
    protected void loadChildMoreNetData() {
        ++pages;
        getUpdatePage();
    }
}
