package com.yzwuhen.abroadproject.bean;

public class UserOrderStateBean extends NetBean {

    /**
     * data : {"audit":0,"write":0,"image":0,"fail":0}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * audit : 0
         * write : 0
         * image : 0
         * fail : 0
         */

        private int audit;
        private int write;
        private int image;
        private int fail;

        public int getAudit() {
            return audit;
        }

        public void setAudit(int audit) {
            this.audit = audit;
        }

        public int getWrite() {
            return write;
        }

        public void setWrite(int write) {
            this.write = write;
        }

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

        public int getFail() {
            return fail;
        }

        public void setFail(int fail) {
            this.fail = fail;
        }
    }
}
