package com.yzwuhen.abroadproject.base;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;


import com.yz.base.BaseView;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.bean.eventBus.EventReLogin;
import com.yzwuhen.abroadproject.ui.activity.LoginAndReister;
import com.yzwuhen.abroadproject.utils.PermissionUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import butterknife.ButterKnife;


/**
 * Created by yz_wuhen on 2017/8/25.
 */

public abstract class BaseActivity<T> extends AppCompatActivity implements BaseView<T> {


    protected BasePresenter presenter;
    FrameLayout mContanier;
    StateView mLoading;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (setNoTitle()) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        }
        setRequestedOrientation(ActivityInfo
                .SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_base);
        mContanier = getView(R.id.contanier);
        mLoading = getView(R.id.loading);
        presenter = getPresenter();
        initView();
        initPresenter();

    }



    public void modifyStateColor(int icolor){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            //设置FLAG_TRANSLUCENT_STATUS透明状态栏
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //根据输入的颜色和透明度显示
            getWindow().setStatusBarColor(getResources().getColor(icolor));
        }
    }

    protected void initView() {

        mContanier.addView(View.inflate(this, getLayoutId(), null));
        ButterKnife.bind(this);

    }

    protected void initPresenter() {
        if (presenter != null) {
            presenter.initRefreshData();
        } else {
            showSuccessView();
        }
    }

    protected boolean setNoTitle() {
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (presenter != null) {
            presenter.destoryView();
            presenter = null;
        }
        ButterKnife.unbind(this);
    }
    public void hintKeyBoard() {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        View v = getWindow().peekDecorView();
        if (null != v) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }

    }
    /**
     * 跳转到其他界面
     */
    public void jumpActivity(Bundle bundle,
                              @SuppressWarnings("rawtypes") Class targetActivity) {
        Intent intent = new Intent();
        intent.setClass(this, targetActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }
    /**
     * @param viewId 根据id获取view对象
     * @return
     */
    @SuppressWarnings("unchecked")
    protected <T extends View> T getView(int viewId) {
        return (T) findViewById(viewId);
    }

    @Override
    public void showLoadingView() {
        if (mLoading!=null)
        mLoading.setLoading();
    }

    /**
     * 关闭网络数据加载布局
     */
    protected void closeProgressView() {
        mLoading.hidView();
        mContanier.setVisibility(View.VISIBLE);
    }

    @Override
    public void showSuccessView() {
        if (mLoading!=null)
        mLoading.hidView();
    }



    @Override
    public void bindMoreDataToView(T t) {

    }


    public abstract int getLayoutId();

    public abstract BasePresenter getPresenter();



}
