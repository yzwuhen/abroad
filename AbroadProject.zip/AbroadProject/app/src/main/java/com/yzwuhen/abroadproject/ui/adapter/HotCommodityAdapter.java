package com.yzwuhen.abroadproject.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.allinterface.VhOnItemClickListener;
import com.yzwuhen.abroadproject.ui.view.CusImageView;
import com.yzwuhen.abroadproject.utils.ImageLoadUtils;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class HotCommodityAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private List<String> mList;
    private VhOnItemClickListener mItemClickListener;

    public HotCommodityAdapter(Context context, List<String> list, VhOnItemClickListener vhOnItemClickListener) {

        this.mContext = context;
        this.mList = list;
        this.mItemClickListener = vhOnItemClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(parent.getContext(), R.layout.item_goods_v1, null);
        return new HotCommodityHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        HotCommodityHolder hotCommodityHolder = (HotCommodityHolder) holder;

      //  ImageLoadUtils.loadImageCenterCrop(mContext,hotCommodityHolder.mIvPic,"http://a.hiphotos.baidu.com/image/h%3D300/sign=b38f3fc35b0fd9f9bf175369152cd42b/9a504fc2d5628535bdaac29e9aef76c6a6ef63c2.jpg",R.mipmap.defult_hot_commodity);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class HotCommodityHolder extends RecyclerView.ViewHolder {

        @Bind(R.id.iv_pic)
        CusImageView mIvPic;
        @Bind(R.id.tv_goods_name)
        TextView mTvGoodsName;
        @Bind(R.id.tv_price)
        TextView mTvPrice;
        @Bind(R.id.tv_cost_price)
        TextView mTvCostPrice;
        public HotCommodityHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItemClickListener.onItemOnclick(v, getAdapterPosition());

                }
            });
        }
    }

}
