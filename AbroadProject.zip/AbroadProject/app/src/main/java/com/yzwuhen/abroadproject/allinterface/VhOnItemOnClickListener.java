package com.yzwuhen.abroadproject.allinterface;

import android.view.View;

/**
 * Created by yz_wuhen on 2017/12/4.
 */

public interface VhOnItemOnClickListener {

    void onItemClick(View v, int... position);
}
