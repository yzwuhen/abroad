package com.yzwuhen.abroadproject.bean.requestBean;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class ReFreeGoodsBean extends BaseRequestBean {
    private int type_id;
    private String search="";
    private String order_by="";
    private int page=1;
    private int limit =20;

    public int getType_id() {
        return type_id;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getOrder_by() {
        return order_by;
    }

    public void setOrder_by(String order_by) {
        this.order_by = order_by;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}
