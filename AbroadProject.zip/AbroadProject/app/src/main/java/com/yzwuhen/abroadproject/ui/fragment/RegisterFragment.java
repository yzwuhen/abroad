package com.yzwuhen.abroadproject.ui.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.RegisterBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventPage;
import com.yzwuhen.abroadproject.ui.activity.RegisterSuccessActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.RegisterPresenter;
import com.yzwuhen.abroadproject.ui.view.InterceptUrlSpan;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import org.greenrobot.eventbus.EventBus;

import butterknife.Bind;
import butterknife.OnClick;

public class RegisterFragment extends BaseFragment<RegisterBean> {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.et_email)
    EditText mEtEmail;
    @Bind(R.id.tv_get_code)
    TextView mTvGetCode;
    @Bind(R.id.et_code)
    EditText mEtCode;
    @Bind(R.id.et_pwd)
    EditText mEtPwd;
    @Bind(R.id.iv_eyes)
    ImageView mIvEyes;
    @Bind(R.id.et_invitation_code)
    EditText mEtInvitationCode;
    @Bind(R.id.iv_check)
    ImageView mIvCheck;
    @Bind(R.id.tv_agreement)
    TextView mTvAgreement;
    @Bind(R.id.tv_next)
    TextView mTvNext;
    @Bind(R.id.iv_next)
    ImageView mIvNext;
    @Bind(R.id.iv_logo)
    ImageView mIvLogo;
    @Bind(R.id.tv_links)
    TextView mTvLinks;

    private String msEmail, msPwd, msCode, msInviteCode;

    private String mVifyCode;

    private boolean isOpenEye;
    private boolean isCheck = true;

    private RegisterPresenter mPresenter;
    private int sTime = 60;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            sTime--;
            if (mTvGetCode != null) {
                mTvGetCode.setText(String.valueOf(sTime) + "s");
                if (sTime > 0) {
                    handler.sendEmptyMessageDelayed(1, 1000);
                } else {
                    mTvGetCode.setText("obtain verification code");
                    mTvGetCode.setEnabled(true);
                    handler.removeCallbacksAndMessages(null);
                }
            }

        }
    };

    @Override
    protected void initView() {
        super.initView();
        mLyRight.setVisibility(View.INVISIBLE);
        mIvLeft.setImageResource(R.mipmap.login_close);
        mIvLogo.setVisibility(View.GONE);
        mTvTitle.setVisibility(View.VISIBLE);
        mTvTitle.setText("registration");
        mTvTitle.setTextColor(getResources().getColor(R.color.black_333));
        mTvTitle.setTextSize(20);
        mIvCheck.setSelected(isCheck);

        mEtEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                msEmail = mEtEmail.getText().toString().trim();
                msPwd = mEtPwd.getText().toString().trim();
                msCode = mEtCode.getText().toString().trim();
                etChange();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEtPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                msEmail = mEtEmail.getText().toString().trim();
                msPwd = mEtPwd.getText().toString().trim();
                msCode = mEtCode.getText().toString().trim();
                etChange();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEtCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                msEmail = mEtEmail.getText().toString().trim();
                msPwd = mEtPwd.getText().toString().trim();
                msCode = mEtCode.getText().toString().trim();
                etChange();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        SpannableStringBuilder style = new SpannableStringBuilder(mTvLinks.getText().toString().trim());
        style.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.email_color)), 16, mTvLinks.getText().toString().trim().length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        mTvLinks.setText(style);

    }

    public void etChange() {
        if (!TextUtils.isEmpty(msEmail) && !TextUtils.isEmpty(msPwd) && !TextUtils.isEmpty(msCode)) {
            mTvNext.setSelected(true);
        } else {
            mTvNext.setSelected(false);
        }
    }

    @Override
    public void bindDataToView(RegisterBean netBean) {

        if (netBean.getError_code() == 0) {

            Bundle bundle = new Bundle();
            bundle.putString(AppConfig.Token,netBean.getData().getToken());
            jumpActivity(bundle, RegisterSuccessActivity.class);
            getActivity().finish();
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_register;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new RegisterPresenter(this);
    }


    @OnClick({R.id.ly_left, R.id.tv_get_code, R.id.iv_eyes, R.id.tv_agreement, R.id.tv_next, R.id.iv_next, R.id.iv_check,R.id.tv_links})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
               getActivity().finish();
                break;
            case R.id.tv_get_code:
                msEmail = mEtEmail.getText().toString().trim();
                if (!TextUtils.isEmpty(msEmail)) {
                    if (!SignUtils.isEmail(msEmail)) {
                        ToastUtils.showMsg("邮箱格式错误");
                        return;
                    }
                    sTime =60;
                    handler.sendEmptyMessage(1);
                    mTvGetCode.setEnabled(false);
                    mPresenter.getCode(msEmail);
                } else {
                    ToastUtils.showMsg("邮箱不能为空");
                }

                break;
            case R.id.tv_links:
                Intent data=new Intent(Intent.ACTION_SENDTO);
                data.setData(Uri.parse("mailto:service@unguya.com"));
                data.putExtra(Intent.EXTRA_SUBJECT, "");
                data.putExtra(Intent.EXTRA_TEXT, "");
                getActivity().startActivity(data);
                break;
            case R.id.iv_eyes:
                if (!isOpenEye) {
                    mIvEyes.setImageResource(R.mipmap.login_open_eyes);
                    isOpenEye = true;
                    //密码可见
                    mEtPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    mIvEyes.setImageResource(R.mipmap.login_close_eyes);
                    isOpenEye = false;
                    //密码不可见
                    mEtPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                break;
            case R.id.iv_check:
                isCheck = !isCheck;
                mIvCheck.setSelected(isCheck);
                break;
            case R.id.tv_agreement:
                Bundle bundle = new Bundle();
                bundle.putString(AppConfig.WEB_LOAD_URL, AppNetConfig.WEB_URL + "agreement?");
                bundle.putString(AppConfig.WEB_TITLE,"Agreement");
                jumpActivity(bundle, WebActivity.class);
                break;
            case R.id.tv_next:
                register();
                break;
            case R.id.iv_next:
            //
                EventBus.getDefault().post(new EventPage(2));
                break;
        }
    }

    private void register() {
        msEmail = mEtEmail.getText().toString().trim();
        msPwd = mEtPwd.getText().toString().trim();
        msCode = mEtCode.getText().toString().trim();
        msInviteCode = mEtInvitationCode.getText().toString().trim();
        if (TextUtils.isEmpty(msEmail)) {
            ToastUtils.showMsg("邮箱不能为空");
            return;
        }
        if (TextUtils.isEmpty(msCode)) {
            ToastUtils.showMsg("验证码不能为空");
            return;
        }
        if (TextUtils.isEmpty(msPwd)) {
            ToastUtils.showMsg("密码不能为空");
            return;
        }

        mPresenter.regist(msEmail, msCode, msPwd, msInviteCode, isCheck);


    }

    public void SetVifyCode(String vifyCode) {

        this.mVifyCode = vifyCode;
    }


    @Override
    public void onStop() {
        super.onStop();
        handler.removeCallbacksAndMessages(null);
    }
}
