package com.yzwuhen.abroadproject.ui.netiml;

import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.bean.FreeTabBean;
import com.yzwuhen.abroadproject.bean.GetCodeBean;
import com.yzwuhen.abroadproject.bean.HomeBean;
import com.yzwuhen.abroadproject.bean.MsgBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.RegisterBean;
import com.yzwuhen.abroadproject.bean.SearchHotBean;
import com.yzwuhen.abroadproject.bean.ShareBean;
import com.yzwuhen.abroadproject.bean.ShareInfoBean;
import com.yzwuhen.abroadproject.bean.UserBean;
import com.yzwuhen.abroadproject.bean.UserOrderStateBean;
import com.yzwuhen.abroadproject.bean.VistorBean;
import com.yzwuhen.abroadproject.ui.UpLoadFileBean;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */

public interface HttpApiInterFace {



    /**
     * 获取游客的识别I
     */
    @FormUrlEncoded
    @POST("client/member/visitor/register")
    rx.Observable<VistorBean> getVisitorId(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token);

    /**
     * 获取验证码
     */
    @FormUrlEncoded
    @POST("system/webservice/verify_code/send_email")
    rx.Observable<GetCodeBean> getCode(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                       @Field("visitor_id") String visitor_id,
                                       @Field("type")String type, @Field("email")String email);

    /**
     * 注册
     */
    @FormUrlEncoded
    @POST("client/member/auth/register")
    rx.Observable<RegisterBean> register(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                         @Field("visitor_id") String visitor_id,
                                         @Field("username")String username, @Field("password")String password, @Field("verify_code")String verify_code, @Field("agreement")String agreement, @Field("invite_code")String invite_code);


    /**
     * 登陆
     */
    @FormUrlEncoded
    @POST("client/member/auth/login")
    rx.Observable<RegisterBean> login(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                         @Field("visitor_id") String visitor_id,
                                         @Field("username")String username, @Field("password")String password);

    /**
     * 退出登陆
     */
    @FormUrlEncoded
    @POST("client/member/auth/logout")
    rx.Observable<RegisterBean> loginOut(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                      @Field("visitor_id") String visitor_id);


    /**
     * 获取用户信息
     */
    @FormUrlEncoded
    @POST("client/member/info/data")
    rx.Observable<UserBean> getUserInfo(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                        @Field("visitor_id") String visitor_id);


    /**
     * 获取分类商品
     */
    @FormUrlEncoded
    @POST("client/shop/goods_type/list")
    rx.Observable<FreeTabBean> getFreeTab(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                          @Field("visitor_id") String visitor_id);




    /**
     * 获取分类商品
     */
    @FormUrlEncoded
    @POST("client/shop/goods/list")
    rx.Observable<FreeGoodsBean> getFreeGoodsList(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                                  @Field("visitor_id") String visitor_id,
                                                  @Field("type_id")Integer type_id, @Field("search")String search, @Field("order_by")String order_by, @Field("page")Integer page, @Field("limit")Integer limit);



    /**
     * 获取首页信息
     */
    @FormUrlEncoded
    @POST(" client/h/index/info")
    rx.Observable<HomeBean> getHomeList(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                        @Field("visitor_id") String visitor_id);

    /**
     * 获取分享链接信息
     */
    @FormUrlEncoded
    @POST("client/member/info/invite_code")
    rx.Observable<ShareBean> getShareLine(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                          @Field("visitor_id") String visitor_id);


    /**
     * 获取我的订单状态下的数量
     */
    @FormUrlEncoded
    @POST("client/h/order/stat")
    rx.Observable<UserOrderStateBean> getOrder(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                               @Field("visitor_id") String visitor_id);

    /**
     * 获取分享已赚
     */
    @FormUrlEncoded
    @POST("client/h/share/info")
    rx.Observable<ShareInfoBean> getShareInfo(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                              @Field("visitor_id") String visitor_id);

    /**
     * 获取热门关键词
     */
    @FormUrlEncoded
    @POST("client/common/keywords/hot")
    rx.Observable<SearchHotBean> getHotList(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                            @Field("visitor_id") String visitor_id);

    /**
     * 上传文件
     */
    @Multipart
    @POST("system/webservice/file/upload")
    rx.Observable<UpLoadFileBean> uploadFile(@Part MultipartBody.Part file, @Part("req_source") RequestBody req_source, @Part("sign") RequestBody sign , @Part("timestamp") RequestBody timestamp , @Part("token") RequestBody token ,
                                             @Part("visitor_id") RequestBody visitor_id, @Part("block") RequestBody block  );


    /**
     * 更新头像
     */
    @FormUrlEncoded
    @POST("client/member/update/head_img")
    rx.Observable<RegisterBean> upDatePic(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                         @Field("visitor_id") String visitor_id,@Field("head_img") Integer head_id);



    /**
     * 更新出生日期
     */
    @FormUrlEncoded
    @POST("client/member/update/birthday")
    rx.Observable<RegisterBean> upDateBirth(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                          @Field("visitor_id") String visitor_id,@Field("year") String year,@Field("month") String month,@Field("day") String day);


    /**
     * 更新性别
     */
    @FormUrlEncoded
    @POST("client/member/update/sex")
    rx.Observable<RegisterBean> upDateSex(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                            @Field("visitor_id") String visitor_id,@Field("sex")Integer sex);

    /**
     * 更新昵称
     */
    @FormUrlEncoded
    @POST("client/member/update/nickname")
    rx.Observable<RegisterBean> upDateNick(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                          @Field("visitor_id") String visitor_id,@Field("nickname")String nickname);


    /**
     * 获取消息
     */
    @FormUrlEncoded
    @POST("client/h/message/index")
    rx.Observable<MsgBean> getMsg(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                  @Field("visitor_id") String visitor_i);


    /**
     * 删除消息
     */
    @FormUrlEncoded
    @POST("client/h/message/delete")
    rx.Observable<NetBean> delete(@Field("req_source") String req_source, @Field("sign") String sign, @Field("timestamp") String timestamp, @Field("token") String token,
                                  @Field("visitor_id") String visitor_i);

}
