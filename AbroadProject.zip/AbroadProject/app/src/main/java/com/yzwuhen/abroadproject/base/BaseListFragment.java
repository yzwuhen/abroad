package com.yzwuhen.abroadproject.base;

import android.support.annotation.Nullable;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;


import com.liaoinstan.springview.widget.SpringView;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;

import butterknife.Bind;


/**
 * Created by yz_wuhen on 2017/8/28.
 */

public abstract class BaseListFragment<T> extends BaseFragment<T> {

    @Bind(R.id.recycle_list)
   protected RecyclerView mRecycleList;
    @Bind(R.id.spring_list)
    protected SpringView mSpringList;
    @Nullable
    @Bind(R.id.tv_no_data)
    protected TextView mTvNoData;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_base_list;
    }

    /*
    * 默认是列表 可复写修改
    * */
    protected void recysetLayoutManager() {
        mRecycleList.setLayoutManager(new LinearLayoutManager(getActivity()));
    }

    @Override
    protected void initView() {
  //      super.initData();
        setSpringStyle();
        recysetLayoutManager();
        mRecycleList.setAdapter(getChildAdapter());
    }

    protected void setSpringStyle(){
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(getContext()));
        mSpringList.setFooter(RefreshHeaderUtils.getFooterView(getContext()));
    }

    @Override
    protected void initListener() {
        super.initListener();
        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                closeProgressView();
               initData();
            }

            @Override
            public void onLoadmore() {
              mSpringList.setEnable(false);
                closeProgressView();
                if(presenter==null){
                    showSuccessView();
                }else{
                    presenter.loadMoreNetData();
                }
            }
        });
    }



    @Override
    public void showSuccessView() {
        super.showSuccessView();
        //重置刷新控件
        closeRefreshView();
    }



    private void closeRefreshView() {
        if (mSpringList!=null){
            mSpringList.setEnable(true);
            mSpringList.onFinishFreshAndLoad();
        }

    }

    protected abstract RecyclerView.Adapter getChildAdapter();
}
