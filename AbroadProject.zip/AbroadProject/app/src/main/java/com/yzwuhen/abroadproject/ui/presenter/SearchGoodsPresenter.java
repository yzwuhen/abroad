package com.yzwuhen.abroadproject.ui.presenter;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.FreeGoodsBean;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReFreeGoodsBean;
import com.yzwuhen.abroadproject.ui.activity.SearchRresultActivity;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class SearchGoodsPresenter extends BasePresenterIml<NetBean> {

    private String mKey;
    ReFreeGoodsBean mFreeGoodsBean = new ReFreeGoodsBean();
    private int page;
    private String order_type="newest";
    public SearchGoodsPresenter(BaseView baseView, String strKey) {
        super(baseView);
        this.mKey =strKey;
    }

    @Override
    public void showErrorStateView() {

    }

    @Override
    protected void requestNetData() {

        page= 0;

        getGoodsList(mKey,"newest",page,AppConfig.Limit);
    }

    public void getGoodsList(String key, String newest, int page, int limit) {
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        map.put("type_id","0");
        map.put("search",key);
        map.put("order_by",newest);
        map.put("page",String.valueOf(page));
        map.put("limit","20");

        mFreeGoodsBean.setPage(page);
        mFreeGoodsBean.setLimit(limit);
        mFreeGoodsBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mFreeGoodsBean.setType_id(0);
        mFreeGoodsBean.setOrder_by(newest);
        mFreeGoodsBean.setSearch(key);
        mFreeGoodsBean.setSign(SignUtils.sign(map));
        mFreeGoodsBean.setTimestamp(map.get("timestamp"));
        mFreeGoodsBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        HttpApiIml.getInstance().create().getFreeGoods(mFreeGoodsBean,new NetSubscriber<FreeGoodsBean>(new SubscriberListener<FreeGoodsBean>(baseView) {
            @Override
            public void onNext(FreeGoodsBean netBean) {

                ((SearchRresultActivity)baseView).upData(netBean,mFreeGoodsBean.getPage());

                if (netBean.getError_code()!=0){
                    ToastUtils.showMsg(netBean.getError_msg());
                }
            }
        }));
    }

    @Override
    protected void loadChildMoreNetData() {
        ++page;
        getGoodsList(mKey,"newest",page,AppConfig.Limit);
    }
}
