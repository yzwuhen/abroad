package com.yzwuhen.abroadproject.ui.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.just.library.AgentWeb;
import com.just.library.DownLoadResultListener;
import com.orhanobut.hawk.Hawk;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseActivity;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventPage;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.net.URLEncoder;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/13/013.
 */

public class WebActivity extends BaseActivity<NetBean> {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.ly_webview)
    LinearLayout mLyWebview;

    private String title;
    private String url;

    private AgentWeb mWebView;

    CallbackManager callbackManager;
    ShareDialog shareDialog;

    private String mUrl,mTitle;


    @Override
    protected void initView() {
        super.initView();

       mIvRight.setImageResource(R.mipmap.mine_share);
        mIvLeft.setImageResource(R.mipmap.sys_back);

        mUrl = getIntent().getStringExtra(AppConfig.WEB_LOAD_URL);
        mTitle = getIntent().getStringExtra(AppConfig.WEB_TITLE);

       mTvTitle.setText(mTitle);

        showDialog();
        if ("Commodity details".equals(mTitle)){
            mLyRight.setVisibility(View.VISIBLE);
            mIvRight.setImageResource(R.mipmap.mine_share);
        }else {
            mLyRight.setVisibility(View.GONE);
        }

        mUrl =mUrl+"token="+ URLEncoder.encode(String.valueOf(Hawk.get(AppConfig.Token,"")))+"&req_source=android";

        Log.v("sss","sssssssssssweburl=====>"+mUrl);

        mWebView = AgentWeb.with(this)//传入Activity or Fragment
                .setAgentWebParent(mLyWebview, new LinearLayout.LayoutParams(-1, -1))//传入AgentWeb 的父控件 ，如果父控件为 RelativeLayout ， 那么第二参数需要传入 RelativeLayout.LayoutParams ,第一个参数和第二个参数应该对应。
                .useDefaultIndicator()// 使用默认进度条
                .defaultProgressBarColor() // 使用默认进度条颜色
                .setReceivedTitleCallback(null) //设置 Web 页面的 title 回调
                .addDownLoadResultListener(mDownLoadResultListener)
                .setWebViewClient(webViewClient)
                .createAgentWeb()//
                .ready()
                .go(mUrl);
    }
    public void showDialog(){
        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);

        shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {

                Log.v("sss","sssssSueecss");
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {
                Log.v("sss","sssssonError"+error.getMessage());
                Log.v("sss","sssssonError");
            }
        });
    }

    WebViewClient webViewClient = new WebViewClient(){

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            Log.v("sss","ssssssssss===================="+url);
            if (url.equals("http://192.168.0.107/relogin"))
            {
                Hawk.delete(AppConfig.Token);
                Hawk.delete(AppConfig.USER_INFO);
                jumpActivity(null, LoginAndReister.class);
                finish();
                return true;
            }
            else if (url.equals("http://member-register.com"))
            {
                Hawk.delete(AppConfig.Token);
                Hawk.delete(AppConfig.USER_INFO);
                Bundle bundle = new Bundle();
                bundle.putInt(AppConfig.LOGIN_PAGE_TYPE,1);//跳转到注册页
                jumpActivity(bundle, LoginAndReister.class);
                finish();
                return true;
            }
           else if (url.equals("http://merchant-apply.com/"))
            {
                finish();
                return true;
            }

            return super.shouldOverrideUrlLoading(view, url);
        }


    };
    public DownLoadResultListener mDownLoadResultListener = new DownLoadResultListener() {
        @Override
        public void success(String path) {

            File file = new File(path);
            Intent intent = new Intent();
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setAction(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.fromFile(file),
                    "application/vnd.android.package-archive");
            startActivity(intent);
        }

        @Override
        public void error(String path, String resUrl, String cause, Throwable e) {

        }
    };
    @Override
    public void bindDataToView(NetBean netBean) {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_webview;
    }

    @Override
    public BasePresenter getPresenter() {
        return null;
    }



    @OnClick({R.id.ly_left,R.id.ly_right})
    public void onViewClicked(View view) {
      switch (view.getId()){
          case R.id.ly_left:
              finish();
              break;
          case R.id.ly_right:
              if (ShareDialog.canShow(ShareLinkContent .class)) {
                  ShareLinkContent linkContent = new ShareLinkContent.Builder()
                          .setContentUrl(Uri.parse(mUrl))
                          .build();
                  shareDialog.show(linkContent);
              }
              break;
      }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }
}
