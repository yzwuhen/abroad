package com.yzwuhen.abroadproject.bean;

import com.yzwuhen.abroadproject.ui.data.UserData;

/**
 * Created by yz_wuhen on 2019/8/30/030.
 */

public class UserBean  extends NetBean{

    /**
     * data : {"username":"920375741@qq.com","nickname":"","sex":0,"head_img":"","birthday":""}
     */

    private UserData data;

    public UserData getData() {
        return data;
    }

    public void setData(UserData data) {
        this.data = data;
    }


}
