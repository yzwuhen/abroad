package com.yzwuhen.abroadproject.ui.widget;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.youth.banner.Banner;
import com.youth.banner.listener.OnBannerListener;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.ui.activity.SearchActivity;
import com.yzwuhen.abroadproject.ui.data.BannerData;
import com.yzwuhen.abroadproject.utils.CircleGidleImageLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yz_wuhen on 2019/10/5/005.
 */

public class BannerView extends LinearLayout implements View.OnClickListener{

    private Context mContext;

    private Banner mBanner;
//    private LinearLayout mLySerach;

    private List<BannerData> mList ;
    List<String>  mListUrl = new ArrayList<>();

    public BannerView(Context context) {
        super(context);
        initView(context);
    }

    public BannerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public BannerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }



    private void initView(Context context) {
        mContext = context;
        View.inflate(mContext, R.layout.item_banner, this);

        mBanner = findViewById(R.id.banner);
//        mLySerach =findViewById(R.id.ly_search);
//
//        mLySerach.setOnClickListener(this);
        mList = new ArrayList<>();


    }

    public void  setData(List<BannerData> banner){

        mList.clear();
        mList.addAll(banner);
        mListUrl.clear();
        if (mList.size()==1){
            mListUrl.add(mList.get(0).getImg_path());
            mListUrl.add(mList.get(0).getImg_path());
        }else {
            for (int i=0;i<mList.size();i++){
                mListUrl.add(mList.get(i).getImg_path());
            }
        }

        mBanner.setImages(mListUrl).setImageLoader(new CircleGidleImageLoader()).start();
        mBanner.isAutoPlay(true);
        mBanner.setDelayTime(6000);
        mBanner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int psition) {


            }

        });

    }

    @Override
    public void onClick(View v) {

        Intent intent = new Intent();
        intent.setClass(mContext, SearchActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        mContext.startActivity(intent);
    }



}
