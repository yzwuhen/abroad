package com.yzwuhen.abroadproject.bean;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class GetCodeBean extends NetBean {

    /**
     * data : {"code":"843330"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * code : 843330
         */

        private String code;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }
}
