package com.yzwuhen.abroadproject.bean.eventBus;

public class EventFree {
    private int type;
    public EventFree(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
