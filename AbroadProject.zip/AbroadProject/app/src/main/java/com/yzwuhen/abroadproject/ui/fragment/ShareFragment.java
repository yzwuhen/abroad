package com.yzwuhen.abroadproject.ui.fragment;

import android.app.DialogFragment;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.zxing.common.StringUtils;
import com.liaoinstan.springview.widget.SpringView;
import com.orhanobut.hawk.Hawk;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.ShareInfoBean;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.adapter.ShareSpeedAdapter;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.SharePresenter;
import com.yzwuhen.abroadproject.utils.PopWindowUtils;
import com.yzwuhen.abroadproject.utils.RefreshHeaderUtils;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yz_wuhen on 2019/10/4/004.
 */

public class ShareFragment extends BaseFragment<ShareInfoBean> {
    @Bind(R.id.tv_share_rule)
    TextView mTvShareRule;
    @Bind(R.id.tv_links_title)
    TextView mTvLinksTitle;
    @Bind(R.id.tv_code)
    TextView mTvCode;
    @Bind(R.id.tv_record)
    TextView mTvRecord;
    @Bind(R.id.rv_list)
    RecyclerView mRvList;
    @Bind(R.id.tv_money)
    TextView mTvMoney;
    @Bind(R.id.spring_list)
    SpringView mSpringList;
    @Bind(R.id.iv_circle)
    ImageView mIcCircle;
    private ShareSpeedAdapter mAdapter;

    private PopWindowUtils mPopWindowUtils;

    private SharePresenter mPresenter;

    private String mShareCode;
    private String mUrl;


    @Override
    protected void initView() {
        super.initView();

        mAdapter = new ShareSpeedAdapter(getActivity());
        mRvList.setLayoutManager(new GridLayoutManager(getContext(), 10));
        mRvList.setAdapter(mAdapter);
        mShareCode = Hawk.get(AppConfig.ShareCode, "");
        mTvCode.setText(mShareCode);
        mSpringList.setType(SpringView.Type.FOLLOW);
        mSpringList.setHeader(RefreshHeaderUtils.getHeaderView(getContext()));


        mSpringList.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                mSpringList.setEnable(false);
                closeProgressView();
                initData();
            }

            @Override
            public void onLoadmore() {

            }
        });
    }

    @Override
    public void bindDataToView(ShareInfoBean netBean) {
        closeRefreshView();
        if (netBean.getError_code() == 0) {
            mAdapter.setData(netBean.getData().getTotal());
            mAdapter.notifyDataSetChanged();
            //显示的时候要除与100
            mTvMoney.setText("$ " + SignUtils.doubleToStrings(netBean.getData().getTotal()));
            if (netBean.getData().getTotal()>=20000){
                mIcCircle.setImageResource(R.drawable.circle_blue);
            }
        }

    }

    public void closeRefreshView() {
        mSpringList.setEnable(true);
        mSpringList.onFinishFreshAndLoad();
    }
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_share;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new SharePresenter(this);
    }


    @OnClick({R.id.tv_share_rule, R.id.tv_record, R.id.tv_copy})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_share_rule:
                biuldPop();
                break;
            case R.id.tv_record:
                Bundle bundle = new Bundle();
                mUrl = AppNetConfig.WEB_URL + "shareing?";
                bundle.putString(AppConfig.WEB_LOAD_URL, mUrl);
                bundle.putString(AppConfig.WEB_TITLE, "Reward record ");
                jumpActivity(bundle, WebActivity.class);
                break;
            case R.id.tv_copy:
                if (TextUtils.isEmpty(Hawk.get(AppConfig.Share_URL, ""))) {
                    ToastUtils.showMsg("no content");
                    return;
                }
                ClipData clipData = ClipData.newPlainText("", Hawk.get(AppConfig.Share_URL, ""));
                ClipboardManager cm = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                // 将文本内容放到系统剪贴板里。
                cm.setPrimaryClip(clipData);
                ToastUtils.showMsg("Copy Success");
                break;
        }
    }

    public void biuldPop() {


        if (mPopWindowUtils == null) {
            mPopWindowUtils = PopWindowUtils.getInstance();
            mPopWindowUtils.general(mContext, new PopWindowUtils.onViewListener() {
                @Override
                public void getView(PopupWindow pop, View view, View parent) {

                }
            }, mTvShareRule, R.layout.pop_share_rule, false);
        }
        mPopWindowUtils.showPop(mTvShareRule);
    }


}
