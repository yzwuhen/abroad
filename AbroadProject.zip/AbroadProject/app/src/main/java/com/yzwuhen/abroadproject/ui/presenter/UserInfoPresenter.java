package com.yzwuhen.abroadproject.ui.presenter;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.config.AppNetConfig;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.requestBean.BaseRequestBean;
import com.yzwuhen.abroadproject.ui.UpLoadFileBean;
import com.yzwuhen.abroadproject.ui.activity.UserInfoActivity;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.ui.netiml.NetSub;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.io.File;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * Created by yz_wuhen on 2019/10/10/010.
 */

public class UserInfoPresenter extends BasePresenterIml<NetBean> {

    BaseRequestBean mBaseRequestBean =new BaseRequestBean();

    public UserInfoPresenter(BaseView baseView) {
        super(baseView);
    }

    @Override
    public void showErrorStateView() {

    }

    @Override
    protected void requestNetData() {

    }

    public void upLoadFile(String path){


        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("block","client");




        File file = new File(path);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file_info", file.getName(), requestFile);

        RequestBody block = RequestBody.create(MediaType.parse("text/plain"), "client");
        RequestBody token = RequestBody.create(MediaType.parse("text/plain"),String.valueOf(Hawk.get(AppConfig.Token,"")));
        RequestBody timestamp = RequestBody.create(MediaType.parse("text/plain"),map.get("timestamp"));
        RequestBody req_source = RequestBody.create(MediaType.parse("text/plain"), "android");
        RequestBody visitor_id = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        RequestBody sgin = RequestBody.create(MediaType.parse("text/plain"), SignUtils.sign(map));

        HttpApiIml.getInstance().create().uploadUserImage(body,token,timestamp,req_source,visitor_id,sgin,block,new NetSub<UpLoadFileBean>(new SubscriberListener<UpLoadFileBean>(baseView) {
            @Override
            public void onNext(UpLoadFileBean upLoadFileBean) {

//                bindDataToView(upLoadFileBean);
                if (upLoadFileBean.getError_code()==0){
                    upDateHeadPic(upLoadFileBean.getData().getFile_id(),upLoadFileBean.getData().getFile_path());
                }
                else {
                    ToastUtils.showMsg(upLoadFileBean.getError_msg());
                }
            }
        }));
    }

    public void upDateHeadPic(int file_id, final String file_path){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("head_img",String.valueOf(file_id));

        mBaseRequestBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mBaseRequestBean.setSign(SignUtils.sign(map));
        mBaseRequestBean.setTimestamp(map.get("timestamp"));
        mBaseRequestBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
            HttpApiIml.getInstance().create().upDataHeadPic(mBaseRequestBean,file_id,new NetSub<NetBean>(new SubscriberListener<NetBean>(baseView) {
                @Override
                public void onNext(NetBean netBean) {
                    if (netBean.getError_code()==0){
                        ((UserInfoActivity)baseView).successed(file_path);
                    } else {
                        ToastUtils.showMsg(netBean.getError_msg());
                    }
                }
            }));

    }
    public void upDateBirth(String years,String month,String day){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("year",years);
        map.put("month",month);
        map.put("day",day);

        mBaseRequestBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mBaseRequestBean.setSign(SignUtils.sign(map));
        mBaseRequestBean.setTimestamp(map.get("timestamp"));
        mBaseRequestBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().upDataBirth(mBaseRequestBean,years,month,day,new NetSub<NetBean>(new SubscriberListener<NetBean>(baseView) {
            @Override
            public void onNext(NetBean netBean) {
                if (netBean.getError_code()==0){
                    ((UserInfoActivity)baseView).successedBirth("");
                }else {
                    ToastUtils.showMsg(netBean.getError_msg());
                }
            }
        }));

    }
    public void upDateSex(final int sex){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("sex",String.valueOf(sex));

        mBaseRequestBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mBaseRequestBean.setSign(SignUtils.sign(map));
        mBaseRequestBean.setTimestamp(map.get("timestamp"));
        mBaseRequestBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().upDataSex(mBaseRequestBean,sex,new NetSub<NetBean>(new SubscriberListener<NetBean>(baseView) {
            @Override
            public void onNext(NetBean netBean) {
                if (netBean.getError_code()==0){
                    ((UserInfoActivity)baseView).successedSex(sex);
                }else {
                    ToastUtils.showMsg(netBean.getError_msg());
                }
            }
        }));

    }
    public void upDateNick(String nick){
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        map.put("nickname",nick);

        mBaseRequestBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mBaseRequestBean.setSign(SignUtils.sign(map));
        mBaseRequestBean.setTimestamp(map.get("timestamp"));
        mBaseRequestBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().upDataNick(mBaseRequestBean,nick,new NetSub<NetBean>(new SubscriberListener<NetBean>(baseView) {
            @Override
            public void onNext(NetBean netBean) {
                if (netBean.getError_code()==0){
                    ((UserInfoActivity)baseView).successedNick();
                    ToastUtils.showMsg("Modified success");
                }else {

                    ToastUtils.showMsg("Modified failed");
                }
            }
        }));

    }

    @Override
    protected void loadChildMoreNetData() {

    }
}
