package com.yzwuhen.abroadproject.bean;

import java.io.Serializable;

/**
 * Created by yz_wuhen on 2017/8/28.
 */

public class NetBean implements Serializable {


    /**
     * error_code : 0
     * error_msg :
     * data : {"a":1,"b":"2...","c":"n"}
     */

    private int error_code;
    private String error_msg;
    private int new_msg;

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public int getNew_msg() {
        return new_msg;
    }

    public void setNew_msg(int new_msg) {
        this.new_msg = new_msg;
    }
}
