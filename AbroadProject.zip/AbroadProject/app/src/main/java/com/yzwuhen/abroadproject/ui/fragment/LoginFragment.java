package com.yzwuhen.abroadproject.ui.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;
import com.yz.config.AppNetConfig;
import com.yzwuhen.abroadproject.R;
import com.yzwuhen.abroadproject.base.BaseFragment;
import com.yzwuhen.abroadproject.base.BasePresenter;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.eventBus.EventPage;
import com.yzwuhen.abroadproject.bean.eventBus.EventUserInfo;
import com.yzwuhen.abroadproject.ui.activity.RegisterSuccessActivity;
import com.yzwuhen.abroadproject.ui.activity.WebActivity;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.presenter.LoginPresenter;
import com.yzwuhen.abroadproject.ui.presenter.RegistSuccessPresenter;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import org.greenrobot.eventbus.EventBus;

import butterknife.Bind;
import butterknife.OnClick;

public class LoginFragment extends BaseFragment<NetBean> {
    @Bind(R.id.iv_left)
    ImageView mIvLeft;
    @Bind(R.id.ly_left)
    LinearLayout mLyLeft;
    @Bind(R.id.tv_title)
    TextView mTvTitle;
    @Bind(R.id.iv_right)
    ImageView mIvRight;
    @Bind(R.id.tv_msg_red)
    TextView mTvMsgRed;
    @Bind(R.id.ly_right)
    RelativeLayout mLyRight;
    @Bind(R.id.ly_title)
    LinearLayout mLyTitle;
    @Bind(R.id.et_e_mail)
    EditText mEtEMail;
    @Bind(R.id.et_pwd)
    EditText mEtPwd;
    @Bind(R.id.iv_eyes)
    ImageView mIvEyes;
    @Bind(R.id.tv_login)
    TextView mTvLogin;
    @Bind(R.id.tv_forget_pwd)
    TextView mTvForgetPwd;
    @Bind(R.id.iv_next)
    ImageView mIvNext;
    @Bind(R.id.iv_logo)
    ImageView mIvLogo;
    private String msEmail,msPwd;

    private boolean isOpenEye;
    private LoginPresenter mPresenter;

    private String mUrl;


    @Override
    protected void initView() {
        super.initView();
        mLyRight.setVisibility(View.INVISIBLE);
        mIvLeft.setImageResource(R.mipmap.login_close);
        mTvTitle.setText("Login");
        mIvLogo.setVisibility(View.GONE);
        mTvTitle.setVisibility(View.VISIBLE);
        mTvTitle.setTextColor(getResources().getColor(R.color.black_333));
        mTvTitle.setTextSize(20);

        if (!TextUtils.isEmpty(Hawk.get(AppConfig.ACCOUNT,""))){
            mEtEMail.setText(Hawk.get(AppConfig.ACCOUNT,""));
            mEtEMail.setSelection(Hawk.get(AppConfig.ACCOUNT,"").length());
        }
        etChange();

        mEtEMail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {



            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                msEmail =mEtEMail.getText().toString().trim();
                msPwd =mEtPwd.getText().toString().trim();
                etChange();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEtPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                msEmail =mEtEMail.getText().toString().trim();
                msPwd =mEtPwd.getText().toString().trim();
                etChange();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void etChange(){
        if (!TextUtils.isEmpty(msEmail)&&!TextUtils.isEmpty(msPwd)){
            mTvLogin.setSelected(true);
            mTvLogin.setEnabled(true);
        }else {
            mTvLogin.setSelected(false);
            mTvLogin.setEnabled(false);
        }
    }

    @Override
    public void bindDataToView(NetBean netBean) {
        EventBus.getDefault().post(new EventUserInfo());
        getActivity().finish();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    public BasePresenter getPresenter() {
        return mPresenter = new LoginPresenter(this);
    }


    @OnClick({R.id.ly_left, R.id.iv_eyes, R.id.tv_login, R.id.tv_forget_pwd, R.id.iv_next})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ly_left:
                getActivity().finish();
                break;
            case R.id.iv_eyes:
                if(!isOpenEye) {
                    mIvEyes.setImageResource(R.mipmap.login_open_eyes);
                    isOpenEye = true;
                    //密码可见
                    mEtPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    mIvEyes.setImageResource(R.mipmap.login_close_eyes);
                    isOpenEye = false;
                    //密码不可见
                    mEtPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                break;
            case R.id.tv_login:
                login();
                break;
            case R.id.tv_forget_pwd:
                mUrl = AppNetConfig.WEB_URL +"forgotpass?";
                Bundle bundle =new Bundle();
                bundle.putString(AppConfig.WEB_LOAD_URL,mUrl);
                bundle.putString(AppConfig.WEB_TITLE,"Forgotpass");
                jumpActivity(bundle, WebActivity.class);
                break;
            case R.id.iv_next:
             //   jumpActivity(null, RegisterActivity.class);
                EventBus.getDefault().post(new EventPage(1));
                break;
        }
    }

    private void login() {

        if (!SignUtils.isEmail(msEmail)){
            ToastUtils.showMsg("邮箱格式错误");
            return;
        }

        mPresenter.login(msEmail,msPwd);
    }
}
