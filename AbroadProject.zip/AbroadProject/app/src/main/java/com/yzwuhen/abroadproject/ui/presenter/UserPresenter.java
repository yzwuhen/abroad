package com.yzwuhen.abroadproject.ui.presenter;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.ShareBean;
import com.yzwuhen.abroadproject.bean.UserOrderStateBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReLoginBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.ui.netiml.NetSub;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

public class UserPresenter extends BasePresenterIml<NetBean> {
    ReLoginBean mReLoginBean = new ReLoginBean();
    public UserPresenter(BaseView baseView) {
        super(baseView);
    }

    @Override
    protected void requestNetData() {

        getOrderNum();
    }

    private void getOrderNum() {

        Map<String,String> map= new HashMap<String,String>();
        map.put("token", String.valueOf(Hawk.get(AppConfig.Token,"")));
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        mReLoginBean.setToken(String.valueOf(Hawk.get(AppConfig.Token,"")));
        mReLoginBean.setSign(SignUtils.sign(map));
        mReLoginBean.setTimestamp(map.get("timestamp"));
        mReLoginBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        HttpApiIml.getInstance().create().getUserOrder(mReLoginBean,new NetSub<UserOrderStateBean>(new SubscriberListener<UserOrderStateBean>(baseView) {
            @Override
            public void onNext(UserOrderStateBean userOrderStateBean) {
                bindDataToView(userOrderStateBean);

            }
        }));
    }

    @Override
    protected void loadChildMoreNetData() {

    }

    @Override
    public void showErrorStateView() {

    }
}
