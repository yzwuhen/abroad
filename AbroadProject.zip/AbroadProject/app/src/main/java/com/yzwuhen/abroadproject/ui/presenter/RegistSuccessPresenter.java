package com.yzwuhen.abroadproject.ui.presenter;

import android.util.Log;

import com.orhanobut.hawk.Hawk;
import com.yz.base.BaseView;
import com.yz.net.NetSubscriber;
import com.yz.net.SubscriberListener;
import com.yzwuhen.abroadproject.App;
import com.yzwuhen.abroadproject.base.BasePresenterIml;
import com.yzwuhen.abroadproject.bean.NetBean;
import com.yzwuhen.abroadproject.bean.ShareBean;
import com.yzwuhen.abroadproject.bean.UserBean;
import com.yzwuhen.abroadproject.bean.requestBean.ReLoginBean;
import com.yzwuhen.abroadproject.ui.globle.AppConfig;
import com.yzwuhen.abroadproject.ui.netiml.HttpApiIml;
import com.yzwuhen.abroadproject.utils.SignUtils;
import com.yzwuhen.abroadproject.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

public class RegistSuccessPresenter extends BasePresenterIml<NetBean> {

    ReLoginBean mReLoginBean = new ReLoginBean();
    public RegistSuccessPresenter(BaseView baseView) {
        super(baseView);
    }

    @Override
    protected void requestNetData() {

    }

    @Override
    protected void loadChildMoreNetData() {

    }

    public void getShareLine(String token) {
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",token);
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id", String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));


        mReLoginBean.setToken(token);
        mReLoginBean.setSign(SignUtils.sign(map));
        mReLoginBean.setTimestamp(map.get("timestamp"));
        mReLoginBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().getLoginShareLine(mReLoginBean,new NetSubscriber<ShareBean>(new SubscriberListener<ShareBean>(baseView) {
            @Override
            public void onNext(ShareBean shareBean) {
                if (shareBean.getError_code()==0){
                    Hawk.put(AppConfig.ShareCode,shareBean.getData().getInvite_code());
                    Hawk.put(AppConfig.Share_URL,shareBean.getData().getInvite_url());
                }
                else {
                    ToastUtils.showMsg(shareBean.getError_msg());
                }
            }
        }));
    }


    public void getUserInfo(String token){
        Log.v("ssssss","ssssssssssssss====token>"+token);
        Map<String,String> map= new HashMap<String,String>();
        map.put("token",token);
        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        map.put("req_source","android");
        map.put("visitor_id",String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));

        mReLoginBean.setToken(token);
        mReLoginBean.setSign(SignUtils.sign(map));
        mReLoginBean.setTimestamp(map.get("timestamp"));
        mReLoginBean.setVisitor_id(String.valueOf(Hawk.get(AppConfig.Visitor_Id,"")));
        HttpApiIml.getInstance().create().getUserInfo(mReLoginBean,new NetSubscriber<UserBean>(new SubscriberListener<UserBean>(baseView) {
            @Override
            public void onNext(UserBean userBean) {
                bindDataToView(userBean);
                if (userBean.getError_code()==0){
                    App.getInstance().setUserData(userBean.getData());
                    Hawk.put(AppConfig.ACCOUNT,userBean.getData().getUsername());
                    Hawk.put(AppConfig.USER_INFO,userBean.getData());
                    ToastUtils.showMsg("Login Success");
                } else {
                    ToastUtils.showMsg(userBean.getError_msg());
                }
            }
        }));
    }


    @Override
    public void showErrorStateView() {

    }
}
