package com.yzwuhen.abroadproject.bean.eventBus;

/**
 * Created by yz_wuhen on 2019/10/11/011.
 */

public class EventUserInfo {
}
