package com.yz.net;

/**
 * Created by zhangguorong on 2017/6/12.
 */

public interface ISubscriberListener<T> {
    void onNext(T t);
    void onError(Throwable e);
    void onCompleted();
    void onStart();
}
