package com.yz.net;


import android.util.Log;

import com.orhanobut.logger.Logger;
import com.yz.config.AppNetConfig;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 作者: by KEN on 2017/4/14 10.
 * 邮箱: gr201655@163.com
 */

public class RetrofitUtil<T> {
    public static final int DEFAULT_TIMOUT = 30;
    public static final int WRITE_TIME = 30;
    private Retrofit mRetrofit;
    private static RetrofitUtil mInstance;

    private RetrofitUtil() {
        OkHttpClient.Builder builder = new OkHttpClient()
                .newBuilder()
                .addInterceptor(new LogInterceptor())
                .retryOnConnectionFailure(true);

        builder.connectTimeout(DEFAULT_TIMOUT, TimeUnit.MINUTES)
                .writeTimeout(WRITE_TIME,TimeUnit.MINUTES)
                .readTimeout(DEFAULT_TIMOUT,TimeUnit.MINUTES);

        mRetrofit = new Retrofit.Builder()
                .client(builder.build())
                .baseUrl(AppNetConfig.NET_HOST)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }
    //作为库，本身不要动的，所以把URL 给出去
    private RetrofitUtil(String url) {
        OkHttpClient.Builder builder = new OkHttpClient()
                .newBuilder()
                .addInterceptor(new CommonInterceptor())
                .retryOnConnectionFailure(true);

        builder.connectTimeout(DEFAULT_TIMOUT, TimeUnit.MINUTES)
                .writeTimeout(WRITE_TIME,TimeUnit.MINUTES)
                .readTimeout(DEFAULT_TIMOUT,TimeUnit.MINUTES);

        mRetrofit = new Retrofit.Builder()
                .client(builder.build())
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

    }
    public static RetrofitUtil getInstance() {
                    mInstance = new RetrofitUtil();
        return mInstance;
    }

    public static RetrofitUtil getInstanceUrl(String url) {
                    mInstance = new RetrofitUtil(url);
        return mInstance;
    }
    public T create(Class<T> clazz) {
        return mRetrofit.create(clazz);
    }


    /*
    * 拦截武器
    * */
    public static class LogInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            String TAG = "NetQuest";
            long t1 = System.nanoTime();

            Request request = chain.request();
            Response response = chain.proceed(request);

            String param = "post".equalsIgnoreCase(request.method()) ? "---REQ：" + "\n" + "       " + bodyToString(request) + "\n" : "";
            String bodyString = response.body().string();
            String beautyPrint;
            long t2 = System.nanoTime();
            if (bodyString.startsWith("{") || bodyString.startsWith("[")) {
                beautyPrint = "--------------REQUEST START------------" + "\n"
                        + String.format("---URL：%s %s in %.1fms", request.url(), request.method(), (t2 - t1) / 1e6d) + "\n"
                        +param
                        + String.format("---RES：%s %d %s", response.protocol().toString(), response.code(), response.message()) + "\n";
                Logger.v(TAG, beautyPrint);
                Log.v(TAG,beautyPrint);
                Logger.json(bodyString);
                Logger.v(TAG, "--------------REQUEST END--------------");
            } else {
                beautyPrint = "--------------REQUEST START------------" + "\n"
                        + String.format("---URL：%s %s in %.1fms", request.url(), request.method(), (t2 - t1) / 1e6d) + "\n"
                        +param
                        + String.format("---RES：%s %d %s", response.protocol().toString(), response.code(), response.message()) + "\n"
                        + bodyString + "\n"
                        + "--------------REQUEST END--------------";
                Log.v(TAG,beautyPrint);
                Logger.v(TAG, beautyPrint);
            }
            return response.newBuilder()
                    .body(ResponseBody.create(response.body().contentType(), bodyString))
                    .build();
        }
    }
    public static String bodyToString(Request request) {
        try {
            final Request copy = request.newBuilder().build();
            final Buffer buffer = new Buffer();
            copy.body().writeTo(buffer);
            return buffer.readUtf8();
        } catch (final IOException e) {
            return "did not work";
        }
    }
}
