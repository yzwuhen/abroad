package com.yz;

import android.support.multidex.MultiDexApplication;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;

/**
 * Created by yz_wuhen on 2017/11/27.
 *
 * 这里把APPlication 写到这 那么主程序必须继承此类 否则接口调用位置会报错
 */

public class NetApplication extends MultiDexApplication {
    private static NetApplication instance;

    public static NetApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance =this;
        Logger.addLogAdapter(new AndroidLogAdapter());
    }
}
