package com.yz.base;

/**
 * Created by yz_wuhen on 2017/8/25.
 */

public interface BaseView<T>{
    /**
     * show loading view
     */
    void showLoadingView();

    /**
     * show success view
     */
    void showSuccessView();

    /**
     * bind data to view
     * @param t  data
     */
    void bindDataToView(T t);



    /**
     * load more data for bind to view
     * @param t
     */
    void bindMoreDataToView(T t);

}
