package com.yz.net;


import com.yz.base.BaseView;

/**
 * Created by zhangguorong on 2017/6/12.
 */

public abstract class SubscriberListener<T> implements ISubscriberListener<T> {
    private BaseView baseView;
    public SubscriberListener(BaseView baseView) {
        this.baseView = baseView;
    }

    @Override
    public void onStart() {
        if(baseView!=null){
            baseView.showLoadingView();
        }
    }

    @Override
    public void onError(Throwable e) {
        if(baseView != null){
         //   baseView.showErrorView();
            baseView = null;
        }
    }

    @Override
    public void onCompleted() {
        if(baseView != null){
            baseView.showSuccessView();
            baseView = null;
        }
    }
}
