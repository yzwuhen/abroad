package com.yz.net.imterface;

/**
 * Created by yz_wuhen on 2017/8/28.
 * <p>
 *
 *这里作案列使用，把此类放至Main中
 */

public interface MainApiInterFace {
/*    @GET("home/getBanner")
    rx.Observable<BannerBean> getBannerList(@Query("key") String key);*/

}
