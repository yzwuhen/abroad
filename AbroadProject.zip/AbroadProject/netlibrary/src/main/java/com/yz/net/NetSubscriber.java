package com.yz.net;


import android.util.Log;

import com.yz.utils.ToastUtils;

import java.net.ConnectException;

import rx.Subscriber;

/**
 * Created by zhangguorong on 2017/6/12.
 */

public class NetSubscriber<T> extends Subscriber<T> {
    private ISubscriberListener<T> listener;

    public NetSubscriber(ISubscriberListener<T> listener) {
        this.listener = listener;
    }

    @Override
    public void onStart() {
        super.onStart();
        listener.onStart();
    }

    @Override
    public void onCompleted() {
        listener.onCompleted();
        if(!isUnsubscribed()){
            unsubscribe();
        }
    }

    @Override
    public void onError(Throwable e) {


        if (e instanceof ConnectException){
            ToastUtils.showMsg("请检查网络");
        }
        listener.onError(e);

        if(!isUnsubscribed()){
            unsubscribe();
        }
    }

    @Override
    public void onNext(T t) {
        if(t !=null){
            listener.onNext(t);

        }
    }
}
