package com.yz.net.iml;

import com.yz.net.RetrofitUtil;
import com.yz.net.imterface.MainApiInterFace;

/**
 * Created by yz_wuhen on 2017/8/28.
 * <p>
 * 这里也同样作为案例，
 */

public class MainApiIml {

    static MainApiIml iml;
    private MainApiInterFace apiInterface;

    public static synchronized  MainApiIml getInstance() {
        if (iml == null) {
            synchronized (MainApiIml.class) {
                if (iml == null) {
                    iml = new MainApiIml();
                }
            }
        }
        return iml;
    }

    public MainApiIml create() {
        iml.apiInterface = (MainApiInterFace) RetrofitUtil.getInstance().create(MainApiInterFace.class);
        return iml;
    }

}
