package com.yz.config;

/**
 * Created by yz_wuhen on 2017/11/27.
 */

public class AppNetConfig {


    public static final String NET_HOST ="http://s.unguya.com/";
    public static final String WEB_URL ="http://h.unguya.com/";
}
