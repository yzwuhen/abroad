package com.yz.net;


import com.yz.net.iml.MainApiIml;

/**
 * Created by yz_wuhen on 2017/8/28.
 */

public class Net {
    public static MainApiIml getMainApiIml(){
        return MainApiIml.getInstance().create();
    }

}
